import logging
import os
import copy

from main.model.device import Device
from main.model.status import Status
from main.process.appium_process import KdpThread
from main.helpers.config_reader import ConfigReader
from main.helpers.device_helper import query_devices
from utils.queue_utils import distribute_data_evenly
from utils.process_utils import kill_appium_processes
from main.helpers.db_helper import DBHelper


logging.basicConfig(level=logging.INFO, format=f"{__name__} %(asctime)s - %(levelname)s - %(message)s")


def main(device_list, settings, data_list, user_list):
    thread_number = min(len(device_list), len(user_list))
    max_upload = settings.get('setting').get('max_upload')
    data_queues = distribute_data_evenly(thread_number, user_list, device_list, data_list, max_upload)

    threads = []

    for i, _queue in enumerate(data_queues):
        device = device_list[i]
        current_settings = copy.deepcopy(settings)
        print("==============================================================")
        print(f"=== SESSION {i}: {device.device_name} ===")
        print(f"Data queue size: {_queue.qsize()}")
        print(f"Data queue: {_queue.queue}\n")

        thread = KdpThread(current_settings, device, _queue)
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()

    logging.info("All threads done!")

def clean_up_previous_run_data():
    file_path = 'cookies.json'
    if os.path.exists(file_path):
        os.remove(file_path)
    else:
        print(f"File {file_path} does not exist")

    # clean up appium processes from previous execution
    kill_appium_processes()


if __name__ == "__main__":
    _settings = ConfigReader('configs/settings.json')

    clean_up_previous_run_data()

    # Scan devices and save to file
    is_scan_new_device = _settings.get('setting').get('scan_device') == 1
    devices = query_devices(is_scan_new_device)

    db_helper = DBHelper()
    db_helper.create_connection()

    # Get all ebooks that are NEW to process uploading
    data = db_helper.get_all_ebooks(Status.NEW.value)

    users = db_helper.get_users()

    main(devices, _settings, data, users)

    # clean_up_previous_run_data()
    db_helper.close_connection()
