"""
By run this setup file, the data from ebooks.xlsx will be added to DB without checking duplication
user from users.xlsx will update if any changes and add new
"""

import os
import pandas as pd
from main.helpers.db_helper import DBHelper
from utils.files_utils import get_path


ebooks_file = get_path('data/ebooks.xlsx')
users_file = get_path('data/users.xlsx')

def setup_database():
    # Initialize DBHelper
    db_helper = DBHelper()
    db_helper.create_connection()

    # Create tables if they don't exist
    db_helper.create_ebook_table()
    # db_helper.create_users_table()

    # Check for ebooks.xlsx and import data if it exists
    if os.path.exists(ebooks_file):
        import_ebooks(db_helper)

    # Check for users.xlsx and import data if it exists
    if os.path.exists(users_file):
        import_users(db_helper)

    db_helper.close_connection()


def import_ebooks(db_helper):
    # Read data from ebooks.xlsx
    ebooks_df = pd.read_excel(ebooks_file)

    # Insert data into ebooks table
    for index, row in ebooks_df.iterrows():
        db_helper.insert_ebook(row)  # Assuming you have an insert_ebook method in your DBHelper


def import_users(db_helper):
    # Read data from users.xlsx
    users_df = pd.read_excel(users_file)

    # Insert data into users table
    for index, row in users_df.iterrows():
        db_helper.insert_or_update_user(row)  # Assuming you have an insert_user method in your DBHelper


if __name__ == "__main__":
    setup_database()
