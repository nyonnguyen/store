import os
import subprocess
import logging
from main.helpers.config_reader import ConfigReader
from utils.files_utils import get_path

# Configure logging
logging.basicConfig(level=logging.INFO, format=f"{__file__} %(asctime)s - %(levelname)s\t%(message)s")
# TODO: This path should be the same with Appium Server's
path = ConfigReader('configs/env.json').get('env')


class AdbCommand(object):
    # ADB_PATH = path['ADB_HOME']
    ADB_PATH = "adb"
    RESOURCE_PATH = get_path(path['UPLOAD_PATH'])
    MEDIA_PATH = "/storage/emulated/0/Download"
    FILE_PACKAGE = "android.intent.action.MEDIA_SCANNER_SCAN_FILE"
    ADB_PUSH = ADB_PATH + " -s %s push %s /storage/emulated/0/Download/%s"
    ADB_REMOVE = ADB_PATH + " -s %s shell rm -rf /storage/emulated/0/Download/%s"
    ADB_MEDIA_SCAN = ADB_PATH + " -s %s shell am broadcast -a %s -d file://%s"
    ADB_CONNECT = ADB_PATH + " connect %s"
    ADB_UNINSTALL = ADB_PATH + " -s %s uninstall "

    def __init__(self, device_name):
        self.device_name = device_name
        self.try_connect_first()
        # self.clean_old_appium_settings()
        print(f"[{self.device_name}] - ADB Inited!")

    def run_command(self, command, error_log=""):
        print(f"[{self.device_name}] - Executing ADB command: {command}")
        command_args = command.split(' ')
        process = subprocess.Popen(command_args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        stdout, stderr = process.communicate()
        if stderr and len(stderr) > 0:
            logging.error(stderr)
            raise RuntimeError('{0}! {1}'.format(error_log, stderr))
        return stdout.decode('utf-8')

    def clean_old_appium_settings(self):
        print(f"[{self.device_name}] - Cleaning old appium agents...")
        old_packages = ['io.appium.settings', 'io.appium.uiautomator2.server', 'io.appium.uiautomator2.server.test']
        for p in old_packages:
            self.run_command(self.ADB_UNINSTALL % self.device_name + p)
        print(f"[{self.device_name}] Cleaning old appium agents... DONE!")

    def try_connect_first(self):
        # Check if device_name has format ip:port
        if ':' in self.device_name:
            os.system(self.ADB_CONNECT % self.device_name)

    def push(self, file):
        self.run_command(self.ADB_PUSH % (self.device_name, f"{self.RESOURCE_PATH}/{file}", file))

    def remove(self, file):
        self.run_command(self.ADB_REMOVE % (self.device_name, file))

    def refresh_media(self):
        os.system(self.ADB_MEDIA_SCAN % (self.device_name, self.FILE_PACKAGE, self.MEDIA_PATH))
