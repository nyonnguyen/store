import sqlite3
from threading import Lock
from sqlite3 import Error
from main.model.kdp import Ebook, User
from main.model.status import Status
from utils.files_utils import get_path

class DBHelper:
    def __init__(self, db_file=get_path('db/kdp.db')):
        """Initialize with the path to the SQLite database file."""
        self.db_file = db_file
        self.conn = None

    def create_connection(self):
        """Create a database connection to the SQLite database."""
        try:
            self.conn = sqlite3.connect(self.db_file)
            self.conn.row_factory = sqlite3.Row
            print(f"Connection to SQLite DB '{self.db_file}' successful")
        except Error as e:
            print(f"Error creating connection: {e}")
        return self.conn

    def close_connection(self):
        """Close the database connection."""
        if self.conn:
            self.conn.close()
            print("Connection closed.")

    def create_ebook_table(self):
        """Create the ebooks table."""
        create_table_sql = """
        CREATE TABLE IF NOT EXISTS ebooks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            CoverName TEXT NOT NULL,
            ContentName TEXT NOT NULL,
            Title TEXT NOT NULL,
            AuthorFirstName TEXT,
            AuthorLastName TEXT,
            Description TEXT,
            CategoryMain TEXT,
            CategorySub TEXT,
            CategoryPlacements TEXT,
            Keywords TEXT,
            ISBN TEXT,
            PrintOption TEXT,
            TrimSize TEXT,
            Bleed BOOLEAN,
            PaperBackCover TEXT,
            AIContent BOOLEAN,
            Price REAL,
            Status TEXT DEFAULT NULL,
            UploadedBy TEXT DEFAULT NULL,
        );
        """
        try:
            self.conn.execute(create_table_sql)
            print("Table 'ebooks' created successfully.")
        except Error as e:
            print(f"Error creating table: {e}")

    def create_users_table(self):
        """Create the users table."""
        create_table_sql = """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            key TEXT NOT NULL
        );
        """
        try:
            self.conn.execute(create_table_sql)
            print("Table 'users' created successfully.")
        except Error as e:
            print(f"Error creating table: {e}")

    def insert_ebook(self, ebook_data):
        """Insert a new ebook record into the ebooks table."""
        sql = """
        INSERT INTO ebooks (
            CoverName, ContentName, Title, AuthorFirstName, AuthorLastName, Description,
            CategoryMain, CategorySub, CategoryPlacements, Keywords, ISBN, PrintOption,
            TrimSize, Bleed, PaperBackCover, AIContent, Price, Status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "NEW");
        """
        try:
            self.conn.execute(sql, ebook_data)
            self.conn.commit()
            print("Ebook inserted successfully.")
        except Error as e:
            print(f"Error inserting ebook: {e}")

    def insert_user(self, user_data):
        """Insert a new user record into the users table."""
        sql = """
        INSERT INTO users (email, password, key)
        VALUES (?, ?, ?);
        """
        try:
            self.conn.execute(sql, user_data)
            self.conn.commit()
            print("User inserted successfully.")
        except Error as e:
            print(f"Error inserting user: {e}")

    def insert_or_update_user(self, user_data):
        """
        Insert a new user record into the users table if the email doesn't exist,
        otherwise update the existing record.
        """

        # SQL query to check if the email exists
        check_sql = "SELECT COUNT(1) FROM users WHERE email = ?"

        # SQL query to insert a new user
        insert_sql = """
        INSERT INTO users (email, password, key)
        VALUES (?, ?, ?);
        """

        # SQL query to update an existing user
        update_sql = """
        UPDATE users
        SET password = ?, key = ?
        WHERE email = ?;
        """

        try:
            cursor = self.conn.cursor()

            # Check if the email already exists
            cursor.execute(check_sql, (user_data[0],))  # user_data[0] is the email
            result = cursor.fetchone()

            if result[0] == 0:  # Email does not exist, insert a new record
                cursor.execute(insert_sql, user_data)
                self.conn.commit()
                print(f"User {user_data[0]} inserted successfully.")
            else:  # Email exists, update the existing record
                cursor.execute(update_sql, (user_data[1], user_data[2], user_data[0]))
                self.conn.commit()
                print(f"User {user_data[0]} updated successfully.")

        except Exception as e:
            print(f"Error inserting or updating user: {e}")

    def update_status(self, ebook_id, status: Status, uploaded_by, title=None):
        print(f"Updating Status to '{status}' for book ID '{ebook_id}' - Title {title}.")
        sql = "UPDATE ebooks SET Status = ?, UploadedBy = ? WHERE id = ?"
        try:
            self.conn.execute(sql, (status, uploaded_by, ebook_id))
            self.conn.commit()
            print(f"Status updated to '{status}' for book ID '{ebook_id}' - Title {title}.")
        except Error as e:
            print(f"Error updating status: {e}")

    def get_unprocessed_ebooks(self):
        """Retrieve all ebooks where the status is NULL (not processed yet)."""
        sql = "SELECT * FROM ebooks WHERE Status IS NULL"
        try:
            cursor = self.conn.cursor()
            cursor.execute(sql)
            rows = cursor.fetchall()
            return rows
        except Error as e:
            print(f"Error retrieving unprocessed ebooks: {e}")
            return []

    def get_all_ebooks(self, status=None):
        """
        Fetch all ebooks data from the database and return them as Ebook objects.
        If a status is provided, only return ebooks with that status.
        """
        cursor = self.conn.cursor()

        # Query depending on whether a status is specified
        # In case, need to query all data has given status and null:
        # SELECT * FROM ebooks WHERE Status = ? OR Status IS NULL
        if status:
            cursor.execute("SELECT * FROM ebooks WHERE Status = ?", (status,))
        else:
            cursor.execute("SELECT * FROM ebooks")

        rows = cursor.fetchall()

        ebooks = []
        for row in rows:
            ebook = Ebook(
                _id=row['id'],
                cover_name=row['CoverName'],
                content_name=row['ContentName'],
                title=row['Title'],
                author_first_name=row['AuthorFirstName'],
                author_last_name=row['AuthorLastName'],
                description=row['Description'],
                category_main=row['CategoryMain'],
                category_sub=row['CategorySub'],
                placements=row['CategoryPlacements'],
                keywords=row['Keywords'],
                isbn=row['ISBN'],
                print_option=row['PrintOption'],
                trim_size=row['TrimSize'],
                bleed=row['Bleed'],
                paper_back_cover=row['PaperBackCover'],
                ai_content=row['AIContent'],
                price=row['Price'],
                status=row['Status'],  # Handling the new status field
                uploaded_by=row['UploadedBy']
            )
            ebooks.append(ebook)

        return ebooks

    def get_users(self):
        """Fetch all users data from the users table and return them as User objects."""
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM users")
        rows = cursor.fetchall()

        users = []
        for row in rows:
            user = User(
                email=row['email'],
                password=row['password'],
                key=row['key']
            )
            users.append(user)

        return users