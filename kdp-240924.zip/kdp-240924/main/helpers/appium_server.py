import logging
import subprocess
import os
import time
from appium.webdriver.appium_service import AppiumService
from main.helpers.config_reader import ConfigReader

logging.basicConfig(level=logging.INFO, format=f"{__name__} %(asctime)s - %(levelname)s\t%(message)s")

path = ConfigReader('configs/env.json').get('env')

os.environ["PATH"] += os.pathsep + path['ANDROID_HOME']+"/platform-tools"
os.environ["PATH"] += os.pathsep + path['ANDROID_HOME']+"/tools/bin"
os.environ["PATH"] += os.pathsep + path['NODE']
log_path = path['LOG_PATH']

env = {
    **os.environ,
    # "ADB_HOME": path['ADB_HOME'],
    # "JAVA_HOME": path['JAVA_HOME'],
}


class AppiumServer(object):
    def __init__(self, server, port):
        self.server = server
        self.port = port
        # self.process = None
        self.appium_service = AppiumService()
        print(f"Inited! {self.port}")

    def _log_info(self, message):
        print(f"Server[{self.port}]/t{message}")

    def stop(self):
        try:
            self.appium_service.stop()
        except:
            if not self.appium_service.is_listening:
                self.appium_service.stop()
        print(f"Appium server stopped! {self.port}")

    def start(self):
        try:
            # args need to add  "--allow-insecure", "chromedriver_autodownload" if any error with chromedriver setup
            self.appium_service.start(args=["--address", f"{self.server}",
                                            "-p", f"{self.port}",
                                            "--allow-insecure", "chromedriver_autodownload",
                                            "--log", f"{log_path}/appium_{self.port}.log"],
                                            env=env)
        except:
            print("Failed to start Appium Server!")
            raise Exception(f"Failed to start Appium Server {self.port}")
        timeout = time.time() + 10
        while time.time() > timeout:
            # Wait for appium server start listening
            if self.appium_service.is_listening:
                return
            else:
                print(f"Waiting for Appium server to start")
                time.sleep(1)
        print(f"Appium server started! {self.port}")
