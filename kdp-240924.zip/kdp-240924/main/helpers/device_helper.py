import subprocess
import json

from main.helpers.config_reader import ConfigReader
from utils.files_utils import get_path
from main.model.device import Device

# Configuration reading
path = ConfigReader('configs/env.json').get('env')
adb_home = path['ADB_HOME']
resource_path = get_path(path['RESOURCE_PATH'])


def query_devices(is_scan=True):
    def get_connected_devices():
        """Get a list of connected devices using adb."""
        result = subprocess.run([f'{adb_home}', 'devices'], stdout=subprocess.PIPE)
        devices_output = result.stdout.decode('utf-8').strip().split('\n')[1:]
        _devices = [line.split('\t')[0] for line in devices_output if 'device' in line]
        return _devices

    def get_device_platform_version(device_id):
        """Get the platform version of a device using adb."""
        result = subprocess.run([f'{adb_home}', '-s', device_id, 'shell', 'getprop', 'ro.build.version.release'],
                                stdout=subprocess.PIPE)
        return result.stdout.decode('utf-8').strip()

    def generate_device_info(device_list):
        """Generate device information and map it to Device objects."""
        device_info_list = []
        for device in device_list:
            platform_version = get_device_platform_version(device)
            # Create a Device object
            device_obj = Device(
                device_name=device,
                udid=device,
                platform_version=platform_version
            )
            device_info_list.append(device_obj)
        return device_info_list

    def save_to_json(device_list, filename=f'{resource_path}/devices.json'):
        """Save the list of Device objects to JSON."""
        with open(filename, 'w') as f:
            # Convert Device objects to dictionaries before saving
            json.dump({"android": [device.to_dict() for device in device_list]}, f, indent=4)

    def get_device_from_json(filename='data/devices.json'):
        devices_json = ConfigReader(filename).get('android')

        _devices = [Device(
            device_name=device.device_name,
            udid=device.udid,
            platform_version=device.platform_version,
            port=device.port
        ) for device in devices_json]
        return _devices

    if is_scan:
        # Query and generate device info
        devices = get_connected_devices()
        device_info = generate_device_info(devices)
        # Save to JSON file
        save_to_json(device_info)
        return device_info
    else:
        return get_device_from_json()
