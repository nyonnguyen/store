import threading
import logging
import time
import queue

from main.helpers.db_helper import DBHelper
from main.model.status import Status
from utils.port_utils import generate_port

from main.drivers.driver_manager import DriverManager
from main.helpers.appium_server import AppiumServer
from main.helpers.adb_helper import AdbCommand
from main.helpers.login_manager import LoginSessionManager
from main.pages.kdp_page import KdpPage
from main.pages.login_page import LoginPage

logging.basicConfig(level=logging.INFO, format=f"{__name__} %(asctime)s - %(levelname)s - %(message)s")

class KdpThread(threading.Thread):

    def __init__(self, settings, device, data_queue):
        threading.Thread.__init__(self)
        self.server_settings = settings.get('setting')
        self.capabilities = settings.get('capabilities')
        self.device = device
        self.data_queue = data_queue

        self.capabilities.update(self.device.to_dict())

        self.server = self.server_settings['server']
        self.port = None
        self.current_user = None
        self.current_data = None
        self.appium_server = None
        self.driver = None
        self.adb = None

        self.db_helper = DBHelper()
        self.db_helper.create_connection()

    # def __del__(self):
    #     self.end_appium_server()

    def start_appium_server(self):
        print(f"[{self.device.device_name}] - STARTING")

        self.server = self.server_settings['server']
        port = self.server_settings.get('port')
        self.port = generate_port(port, 100)

        self.appium_server = AppiumServer(self.server, self.port)
        self.appium_server.start()

    def end_appium_server(self):
        if self.appium_server:
            self.appium_server.stop()
            print(f"[{self.device.device_name}] - END")

    def prepare_upload_files(self, data):
        self.cleanup_upload_files()
        print(f"[{self.device.device_name}] - Preparing upload files....")
        # Push files to device
        self.adb.push(data.cover_name)
        self.adb.push(data.content_name)
        time.sleep(1)
        self.adb.refresh_media()
        time.sleep(3)

    def cleanup_upload_files(self):
        print(f"[{self.device.device_name}] - Cleaning upload files....")
        self.adb.remove("*.pdf")    # Remove all PDF files
        time.sleep(1)
        self.adb.refresh_media()
        time.sleep(3)

    def start_publish(self, data) -> Status:
        print(f"[{self.device.device_name}] - Publishing {data}")
        kdp_page = KdpPage(self.driver, data)
        kdp_page.navigate()
        return kdp_page.publish()

    @staticmethod
    def _login_kdp(driver, device, user_info):
        print(f"[{device.device_name}] -Logging in with {user_info.email}")
        login_page = LoginPage(driver)
        login_page.login(user_info.email, user_info.password, user_info.key)
        print(f"[{device.device_name}] - Completed Logging in!")

    def run(self):
        self.start_appium_server()
        while True:
            try:
                data_p, user = self.data_queue.get_nowait()
                self.current_data = data_p
                self.current_user = user
                print(f"[{self.device.device_name}] - RUNNING {self.current_user.email}")

                # Start ADB helper
                self.adb = AdbCommand(self.capabilities['deviceName'])
                self.prepare_upload_files(self.current_data)

                # Start WebDriver
                # driver_manager = DriverManager(f"http://{self.server}:{self.device['port']}", self.capabilities)
                driver_manager = DriverManager(f"http://{self.server}:{self.port}", self.capabilities)
                self.driver = driver_manager.start_driver()
                self.driver.get("https://kdp.amazon.com/en_US/bookshelf")
                print(
                    f"[{self.device.device_name}] - Created new WebDriver with account {self.current_user.email}")

                login_session = LoginSessionManager(self.driver, self.device, self.current_user, self._login_kdp)
                login_session.login()

                db_helper = DBHelper()
                db_helper.create_connection()

                # TODO: When start with data, write UPLOADING to db
                db_helper.update_status(self.current_data.id, Status.IN_PROGRESS.value, self.current_user.email)
                upload_status = self.start_publish(self.current_data)

                # TODO: After upload success, update UPLOADED, otherwise, update FAILED
                db_helper.update_status(self.current_data.id, upload_status.value, self.current_user.email)

                print(f"[{self.device.device_name}] - STOP")

                # Mark task as done
                self.data_queue.task_done()

            except queue.Empty:
                print(f"[{self.device.device_name}] - Queue is empty, exiting loop")
                break

            except Exception as e:
                logging.warning(f"[{self.device.device_name}] - Error: {e}")

            finally:
                print(f"[{self.device.device_name}] - CLOSE")
        if hasattr(self, 'adb_helper'):
            self.db_helper.close_connection()
        if hasattr(self, 'driver'):
            if self.driver:
                self.driver.quit()
        if hasattr(self, 'appium_server'):
            self.end_appium_server()
