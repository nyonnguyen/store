import queue

def distribute_data_evenly(thread_number, user_list, device_list, data_list, max_upload=3) -> list:
    '''
    Distribute data evenly to each account while prioritizing device utilization and adhering to max_upload.
    :param thread_number: number of threads to handle data distribution
    :param user_list: list of accounts (each account represented by a dictionary with 'email' key)
    :param device_list: list of available devices
    :param data_list: list of data items to be uploaded
    :param max_upload: maximum number of data items that can be uploaded to each account
    :return: list of queues, each queue contains data items assigned to an account on a device
    '''
    supported_devices = device_list[:thread_number]
    queues = [queue.Queue() for _ in supported_devices]

    user_data_count = {user.email: 0 for user in user_list}  # Tracks upload count per user
    total_upload_slots = len(user_list) * max_upload
    data_per_device = len(data_list) // len(supported_devices)  # Target distribution per device

    if len(data_list) > total_upload_slots:
        print(f"Warning: Only {total_upload_slots} data items can be uploaded, but {len(data_list)} were provided.")

    for i, data_item in enumerate(data_list):
        assigned = False
        for j, user in enumerate(user_list):
            # Ensure the user hasn't reached the max_upload limit
            if user_data_count[user.email] < max_upload:
                device_index = j % len(supported_devices)  # Assign in a round-robin fashion
                queues[device_index].put((data_item, user))
                user_data_count[user.email] += 1
                assigned = True
                break

        if not assigned:
            # If no account is eligible to receive more data, stop processing
            remaining = data_list[i:]
            print(f"Remaining unassigned data: {remaining}")
            break

    return queues