import os


def get_project_root():
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def get_path(file):
    project_root = get_project_root()
    return f"{project_root}/{file}"
