import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import EbooksTab from './components/EbooksTab';
import UsersTab from './components/UsersTab';
import DevicesTab from './components/DevicesTab';
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css'; // Import Font Awesome CSS
import './App.css'; // Import the CSS file

function App() {
  return (
    <Router>
      <div className="container kdp-container">
        <h1 style={{textAlign: 'center'}}>KDP Tool</h1>
        <div className="row">
          <div className="col-md-3 fixed-nav">
            <nav>
              <ul className="nav flex-column nav-tabs">
                <li className="nav-item">
                  <Link className="nav-link" to="/ebooks">
                    <i className="fas fa-book"></i> Ebooks
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/users">
                    <i className="fas fa-users"></i> Users
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/devices">
                    <i className="fas fa-tablet-alt"></i> Devices
                  </Link>
                </li>
              </ul>
            </nav>
          </div>
          <div className="col-md-9">
            <Routes>
              <Route path="/ebooks" element={<EbooksTab/>}/>
              <Route path="/users" element={<UsersTab/>}/>
              <Route path="/devices" element={<DevicesTab/>}/>
              <Route path="/" element={<h2>Welcome to the KDP Website</h2>}/>
            </Routes>
          </div>
        </div>
      </div>
    </Router>
  );
}

export default App;