import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './DevicesTab.css';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const DevicesTab = () => {
  const [devices, setDevices] = useState([]);
  const [countdown, setCountdown] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Pagination states
  const [currentPage, setCurrentPage] = useState(1);
  const [devicesPerPage] = useState(50); // Number of devices per page (you can adjust this)

  const fetchDevices = () => {
    let lastDeviceScan = localStorage.getItem('lastDeviceScan');
    lastDeviceScan = lastDeviceScan ? parseInt(lastDeviceScan) : null;
    const currentTime = new Date().getTime();
    console.log("Last Device Scan: ", lastDeviceScan);
    console.log("Current Time: ", currentTime);
    if (lastDeviceScan) {
      if (currentTime - lastDeviceScan === 30000) { // 30 seconds in milliseconds
        const skip_message = "Devices were scanned less than 30 seconds ago. Skipping fetch.";
        toast.info(skip_message);
        console.log(skip_message);
        setCountdown(Math.round((currentTime - lastDeviceScan) / 1000));
        return;
      }
    }

    axios.get('/devices/')
      .then(({ data: { devices, message, status } }) => {
        if (status === 200) {
          setDevices(devices);
          localStorage.setItem('devices', JSON.stringify(devices)); // Save devices to localStorage
          const currentTime = new Date().getTime();
          localStorage.setItem('lastDeviceScan', currentTime); // Save last scan time to localStorage
          setIsRefreshing(true);  // Re-enable button after fetching data
          setCountdown(30);        // Start countdown from 30 seconds
          toast.success(devices.length + " devices found!");
          console.log(devices.length + " devices found!");

        } else if (status === 202) {
          toast.info(message);
        } else {
          toast.error(message);
        }
        console.log(message);
      })
      .catch(err => {
        console.error(err);
        toast.error("Failed to fetch devices");
      });
  };

  // Load devices and last scan time from localStorage when the component mounts
  useEffect(() => {
    const savedDevices = localStorage.getItem('devices');
    if (savedDevices) {
      setDevices(JSON.parse(savedDevices));
    }
    let lastScanTime = localStorage.getItem('lastDeviceScan');
    lastScanTime = lastScanTime ? parseInt(lastScanTime) : null;
    if (lastScanTime) {
      const currentTime = new Date().getTime();
      console.log("Last Device Scan: ", lastScanTime);
      console.log("Current Time: ", currentTime);
      const timeDiff = (currentTime - lastScanTime) / 1000; // Time difference in seconds
      if (timeDiff < 30) {
        setCountdown(Math.round(30 - timeDiff)); // Set countdown based on the time difference
      }
    }
    // fetchDevices()
  }, []);

  // Countdown Refresh button logic
  useEffect(() => {
    let timer;
    if (countdown > 0) {
      timer = setTimeout(() => setCountdown(countdown - 1), 1000);  // Decrement countdown every second
    }
    return () => {
      clearTimeout(timer);
      setIsRefreshing(false);  // Re-enable button after countdown is done

    }
  }, [countdown]);

  // Auto-refresh devices every 5 minutes
  useEffect(() => {
    fetchDevices()
    const interval = setInterval(fetchDevices, 300000); // Auto refresh every 5 minutes (300000ms)
    return () => clearInterval(interval);
  }, []);

  // Handle the button click to refresh manually
  const handleRefreshClick = () => {
    if (!isRefreshing) {
      setIsRefreshing(true);  // Disable button
      fetchDevices();         // Fetch devices and start countdown
    }
  };

  // Pagination logic
  const indexOfLastDevice = currentPage * devicesPerPage;
  const indexOfFirstDevice = indexOfLastDevice - devicesPerPage;
  const currentDevices = devices.slice(indexOfFirstDevice, indexOfLastDevice);

  const totalPages = Math.ceil(devices.length / devicesPerPage);

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  return (
    <div className="container mt-4">
      <ToastContainer /> {/* Add ToastContainer here */}
      <h3>Scanned Devices List</h3>
      <button
        className="btn btn-primary mb-3"
        onClick={handleRefreshClick}
        disabled={isRefreshing || countdown > 0}
      >
        {countdown > 0 ? `Refresh (${countdown}s)` : 'Refresh'}
      </button>

      <p>Total Devices: {devices.length}</p>  {/* Display total number of devices */}

      <table className="table table-bordered">
        <thead>
          <tr>
            <th>Device Name</th>
            <th>UDID</th>
            <th>Platform Version</th>
            <th>Port</th>
          </tr>
        </thead>
        <tbody>
          {currentDevices.map((device) => (
            <tr key={device.deviceName}>
              <td>{device.deviceName}</td>
              <td>{device.udid}</td>
              <td>{device.platformVersion}</td>
              <td>{device.port}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Pagination controls */}
      <div className="pagination-controls">
        <button
          className="btn btn-secondary me-2"
          onClick={handlePrevPage}
          disabled={currentPage === 1}
        >
          Previous
        </button>

        {Array.from({ length: totalPages }, (_, i) => i + 1).map(pageNumber => (
          <button
            key={pageNumber}
            className={`btn ${pageNumber === currentPage ? 'btn-primary' : 'btn-outline-primary'} me-2`}
            onClick={() => handlePageChange(pageNumber)}
          >
            {pageNumber}
          </button>
        ))}

        <button
          className="btn btn-secondary"
          onClick={handleNextPage}
          disabled={currentPage === totalPages}
        >
          Next
        </button>
      </div>

      <p>Page {currentPage} of {totalPages}</p> {/* Display current page and total pages */}
    </div>
  );
};

export default DevicesTab;