import React, { useState, useEffect } from 'react';
import { Modal, Form, Button, Row, Col } from 'react-bootstrap';
import Select from 'react-dropdown-select';
import './EbookModal.css'; // Import the CSS file

const EbookModal = ({ show, handleClose, handleSubmit, formData, setFormData, isEdit }) => {
  const [coverFile, setCoverFile] = useState(null);
  const [contentFile, setContentFile] = useState(null);
  const [subCategoryOptions, setSubCategoryOptions] = useState([]);
  const [placementOptions, setPlacementOptions] = useState([]);
  const [categoryOptions, setCategoryOptions] = useState([]);
  const [categoryData, setCategoryData] = useState({ categories: {}, placements: {} });

  useEffect(() => {
    if (!isEdit) {
      setFormData({
        title: '',
        author_first_name: '',
        author_last_name: '',
        cover_name: '',
        content_name: '',
        category_main: '',
        category_sub: '',
        placements: '',
        keywords: '',
        isbn: '',
        print_option: 'BW_WHITE',
        trim_size: '6 x 9',
        bleed: '0',
        paper_back_cover: 'matte',
        ai_content: '0',
        description: '',
        status: 'NEW',
        price: 0.0
      });
    } else {
      // Load dependent options based on formData
      if (formData.category_main) {
        updateDependentOptions('category_main', formData.category_main);
      }
      if (formData.category_sub) {
        updateDependentOptions('category_sub', formData.category_sub);
      }
    }
  }, [show, isEdit]);

  useEffect(() => {
    fetch('/categories.json')
      .then(response => response.json())
      .then(data => {
        setCategoryData(data);
        const categories = Object.keys(data.categories).map(key => ({ value: key, label: key }));
        setCategoryOptions(categories);
      })
      .catch(error => console.error('Error fetching categories:', error));
  }, []);

  const isValidFormData = (data) => {
    return data && typeof data === 'object' && !Array.isArray(data);
  };

  if (!isValidFormData(formData)) {
    return <div>Error: Invalid form data</div>;
  }

  const handleFileChange = (e, setFile, fieldName) => {
    const file = e.target.files[0];
    setFile(file);
    if (file) {
      setFormData(prevFormData => ({
        ...prevFormData,
        [fieldName]: file.name
      }));
    }
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    const formDataWithFiles = new FormData();
    Object.keys(formData).forEach(key => {
      formDataWithFiles.append(key, formData[key]);
    });
    if (coverFile) {
      formDataWithFiles.append('cover_file', coverFile);
    }
    if (contentFile) {
      formDataWithFiles.append('content_file', contentFile);
    }
    handleSubmit(formDataWithFiles);
  };

  const handleSelectChange = (selected, fieldName) => {
    setFormData(prevFormData => ({
      ...prevFormData,
      [fieldName]: selected.length > 0 ? selected[0].value : ''
    }));

    const selectedMainCategory = selected.length > 0 ? selected[0].value : '';
    updateDependentOptions(fieldName, selectedMainCategory);
  };

  const updateDependentOptions = (fieldName, selectedCategory) => {
    if (fieldName === 'category_main') {
      const categories = categoryData.categories[selectedCategory] || [];
      setSubCategoryOptions(categories.map(sub => ({ value: sub, label: sub })));
    }
    if (fieldName === 'category_sub') {
      const placements = categoryData.placements[selectedCategory] || [];
      setPlacementOptions(placements.map(place => ({ value: place, label: place })));
    }
  };

  return (
    <Modal show={show} onHide={handleClose} size="lg" className="ebook-modal">
      <Modal.Header closeButton>
        <Modal.Title>{isEdit ? 'Edit eBook' : 'Add eBook'}</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form onSubmit={handleFormSubmit}>
          <Row>
            <Col>
              <Form.Group controlId="formTitle">
                <Form.Label>Title *</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter title"
                  value={formData.title || ""}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  required
                />
              </Form.Group>
            </Col>
          </Row>

          <Row>
            <Col>
              <Form.Group controlId="formAuthorFirstName">
                <Form.Label>Author First Name *</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter first name"
                  value={formData.author_first_name || ""}
                  onChange={(e) => setFormData({ ...formData, author_first_name: e.target.value })}
                  required
                />
              </Form.Group>
            </Col>
            <Col>
              <Form.Group controlId="formAuthorLastName">
                <Form.Label>Author Last Name *</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter last name"
                  value={formData.author_last_name || ""}
                  onChange={(e) => setFormData({ ...formData, author_last_name: e.target.value })}
                  required
                />
              </Form.Group>
            </Col>
          </Row>

          <Row>
            <Col>
              <Form.Group controlId="formCoverFile">
                <Form.Label>Cover Name</Form.Label>
                <Form.Control
                  type="file"
                  accept="application/pdf"
                  onChange={(e) => handleFileChange(e, setCoverFile, 'cover_name')}
                />
                {formData.cover_name && <Form.Text className="text-muted">Current file: {formData.cover_name}</Form.Text>}
              </Form.Group>
            </Col>
            <Col>
              <Form.Group controlId="formContentFile">
                <Form.Label>Content Name</Form.Label>
                <Form.Control
                  type="file"
                  accept="application/pdf"
                  onChange={(e) => handleFileChange(e, setContentFile, 'content_name')}
                />
                {formData.content_name && <Form.Text className="text-muted">Current file: {formData.content_name}</Form.Text>}
              </Form.Group>
            </Col>
          </Row>

          <Row>
            <Col>
              <Form.Group controlId="formCategoryMain">
                <Form.Label>Main Category *</Form.Label>
                <Select
                  options={categoryOptions}
                  onChange={(selected) => handleSelectChange(selected, 'category_main')}
                  values={categoryOptions.filter(option => option.value === formData.category_main)}
                  required
                />
              </Form.Group>
            </Col>
            <Col>
              <Form.Group controlId="formCategorySub">
                <Form.Label>Sub Category (Optional)</Form.Label>
                <Select
                  options={subCategoryOptions}
                  onChange={(selected) => handleSelectChange(selected, 'category_sub')}
                  values={subCategoryOptions.filter(option => option.value === formData.category_sub) || formData.category_sub}
                />
              </Form.Group>
            </Col>
          </Row>
          <Row>
            <Col>
              <Form.Group controlId="formPlacements">
                <Form.Label>Placements *</Form.Label>
                <Select
                  options={placementOptions}
                  onChange={(selected) => handleSelectChange(selected, 'placements')}
                  values={placementOptions.filter(option => option.value === formData.placements) || formData.placements}
                  required
                />
              </Form.Group>
            </Col>
            <Col>
              <Form.Group controlId="formKeywords">
                <Form.Label>Keywords (Optional)</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter keywords"
                  value={formData.keywords ? formData.keywords : null}
                  onChange={(e) => setFormData({ ...formData, keywords: e.target.value })}
                />
              </Form.Group>
            </Col>
          </Row>
          <Row>
            <Col>
              <Form.Group controlId="formAiContent">
                <Form.Label>AI Content (Optional)</Form.Label>
                <Form.Control
                  as="select"
                  value={formData.ai_content || "0"}
                  onChange={(e) => setFormData({ ...formData, ai_content: e.target.value })}
                >
                  <option value="0">No</option>
                  <option value="1">Yes</option>
                </Form.Control>
              </Form.Group>
            </Col>
            <Col>
              <Form.Group controlId="formIsbn">
                <Form.Label>ISBN (Optional)</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter ISBN"
                  value={formData.isbn || ""}
                  onChange={(e) => setFormData({ ...formData, isbn: e.target.value })}
                />
              </Form.Group>
            </Col>
          </Row>

          <Row>
            <Col>
              <Form.Group controlId="formPrintOption">
                <Form.Label>Print Option (Optional)</Form.Label>
                <Form.Control
                  as="select"
                  value={formData.print_option || "BW_WHITE"}
                  onChange={(e) => setFormData({ ...formData, print_option: e.target.value })}
                >
                  <option value="BW_WHITE">Black & White</option>
                  <option value="COLOR">Color</option>
                </Form.Control>
              </Form.Group>
            </Col>
            <Col>
              <Form.Group controlId="formTrimSize">
                <Form.Label>Trim Size (Optional)</Form.Label>
                <Form.Control
                  as="select"
                  value={formData.trim_size || "6 x 9"}
                  onChange={(e) => setFormData({ ...formData, trim_size: e.target.value })}
                >
                  <option value="6 x 9">6 x 9</option>
                  <option value="5 x 8">5 x 8</option>
                  <option value="5.25 x 8">5.25 x 8</option>
                  <option value="5.5 x 8.5">5.5 x 8.5</option>
                  <option value="7 x 10">7 x 10</option>
                  <option value="8 x 10">8 x 10</option>
                  <option value="8.5 x 11">8.5 x 11</option>
                </Form.Control>
              </Form.Group>
            </Col>
          </Row>

          <Row>
            <Col>
              <Form.Group controlId="formBleed">
                <Form.Label>Bleed (Optional)</Form.Label>
                <Form.Control
                  as="select"
                  value={formData.bleed || "0"}
                  onChange={(e) => setFormData({ ...formData, bleed: e.target.value })}
                >
                  <option value="0">No</option>
                  <option value="1">Yes</option>
                </Form.Control>
              </Form.Group>
            </Col>
            <Col>
              <Form.Group controlId="formPaperBackCover">
                <Form.Label>Paper Back Cover (Optional)</Form.Label>
                <Form.Control
                  as="select"
                  value={formData.paper_back_cover || "matte"}
                  onChange={(e) => setFormData({ ...formData, paper_back_cover: e.target.value })}
                >
                  <option value="matte">Matte</option>
                  <option value="glossy">Glossy</option>
                </Form.Control>
              </Form.Group>
            </Col>
          </Row>
          <Row>
            <Col>
              <Form.Group controlId="formDescription">
                <Form.Label>Description *</Form.Label>
                <Form.Control
                  as="textarea"
                  rows={3}
                  placeholder="Enter description"
                  value={formData.description || ""}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  required
                />
              </Form.Group>
            </Col>
          </Row>
          <Row>
            <Col>
              <Form.Group controlId="formStatus">
                <Form.Label>Status *</Form.Label>
                <Form.Control
                  as="select"
                  value={formData.status || "NEW"}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                  required
                >
                  <option value="NEW">NEW</option>
                  <option value="IN_PROGRESS">IN_PROGRESS</option>
                  <option value="DONE">DONE</option>
                  <option value="FAILED">FAILED</option>
                  <option value="SKIPPED">SKIPPED</option>
                </Form.Control>
              </Form.Group>
            </Col>
            <Col>
              <Form.Group controlId="formPrice">
                <Form.Label>Price *</Form.Label>
                <Form.Control
                  type="number"
                  step="0.01"
                  placeholder="Enter price"
                  value={formData.price || 0.0}
                  onChange={(e) => setFormData({ ...formData, price: parseFloat(e.target.value) })}
                  required
                />
              </Form.Group>
            </Col>
          </Row>
          <Modal.Footer>
            <Button variant="success" type="submit">
              {isEdit ? 'Save Changes' : 'Add eBook'}
            </Button>
          </Modal.Footer>
        </Form>
      </Modal.Body>
    </Modal>
  );
};

export default EbookModal;