import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Modal, Button, Form } from 'react-bootstrap';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import './UsersTab.css';

const UsersTab = () => {
  const [users, setUsers] = useState([]);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    key: '',
    active: ''
  });

  const [showModal, setShowModal] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [usersPerPage] = useState(10);
  const [selectedUsers, setSelectedUsers] = useState(new Set());
  const [isEdit, setIsEdit] = useState(false);
  const [editUserEmail, setEditUserEmail] = useState(null);
  const [filter, setFilter] = useState('');

  const fetchUsers = () => {
    axios.get('/users/')
      .then(res => setUsers(res.data))
      .catch(err => console.error(err));
  };

  useEffect(() => {
    fetchUsers();
    const interval = setInterval(fetchUsers, 30000);
    return () => clearInterval(interval);
  }, []);

  const handleDelete = (email) => {
    if (window.confirm(`Are you sure you want to delete user ${email}?`)) {
      axios.delete(`/users/${email}`)
        .then(({ data: {message, status} }) => {
          if (status === 200) {
            toast.success(message);
          } else {
            toast.error(message);
          }
          fetchUsers();
        })
        .catch(err => {
          console.error(err);
          toast.error('An error occurred. Please try again.');
        });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post(`/users/`, formData)
      .then(({ data: {message, status} }) => {
        if (status === 200) {
          toast.success(message);
        } else {
          toast.error(message);
        }
        fetchUsers();
        setShowModal(false);
      })
      .catch(err => {
        console.error(err);
        toast.error('An error occurred. Please try again.');
      });
  };

  const handleSave = (e) => {
    e.preventDefault();
    const email = formData.email;
    const active = formData.active;
    axios.put(`/users/${email}/${active}`)
      .then(({ data: {message, status} }) => {
        if (status === 200) {
          toast.success(message);
        } else {
          toast.error(message);
        }
        fetchUsers();
        setShowModal(false);
        setIsEdit(false);
        setEditUserEmail(null);
      })
      .catch(err => {
        console.error(err);
        toast.error('An error occurred. Please try again.');
      });
  };

  const handleSelectUser = (email) => {
    const newSelectedUsers = new Set(selectedUsers);
    if (newSelectedUsers.has(email)) {
      newSelectedUsers.delete(email);
    } else {
      newSelectedUsers.add(email);
    }
    setSelectedUsers(newSelectedUsers);
  };

  const handleSelectAllUsers = () => {
    if (selectedUsers.size === users.length) {
      setSelectedUsers(new Set());
    } else {
      setSelectedUsers(new Set(users.map(user => user.email)));
    }
  };

  const handleEdit = (user) => {
    setFormData({
      email: user.email,
      active: user.active
    });
    setIsEdit(true);
    setEditUserEmail(user.email);
    setShowModal(true);
  };

  const countSelectedUsers = () => selectedUsers.size;

  const indexOfLastUser = currentPage * usersPerPage;
  const indexOfFirstUser = indexOfLastUser - usersPerPage;
  const filteredUsers = users.filter(user => user.email.toLowerCase().includes(filter.toLowerCase()));
  const currentUsers = filteredUsers.slice(indexOfFirstUser, indexOfLastUser);
  const totalPages = Math.ceil(filteredUsers.length / usersPerPage);

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  return (
      <div className="container mt-4">
        <ToastContainer/>
        <h3>Users List</h3>
        <div className="d-flex mb-3">
          <button className="btn btn-primary me-2" onClick={fetchUsers}>Refresh</button>
          <button className="btn btn-success" onClick={() => setShowModal(true)}>Add User</button>
        </div>

        <div>
          <input
              type="text"
              placeholder="Filter by email"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="mb-3"
          />
        </div>

        <div>
          Selected {countSelectedUsers()} row of {users.length}
        </div>

        <table className="table table-bordered">
          <thead>
          <tr>
            <th>
              <input
                  type="checkbox"
                  checked={selectedUsers.size === users.length}
                  onChange={handleSelectAllUsers}
              />
            </th>
            <th>Email</th>
            <th>Active</th>
            <th>Actions</th>
          </tr>
          </thead>
          <tbody>
          {currentUsers.map((user) => (
              <tr key={user.email} className={`active-${user.active ? 'yes' : 'no'}`}>
                <td>
                  <input
                      type="checkbox"
                      checked={selectedUsers.has(user.email)}
                      onChange={() => handleSelectUser(user.email)}
                  />
                </td>
                <td>{user.email}</td>
                <td>{user.active ? 'Yes' : 'No'}</td>
                <td>
                  <button className="btn btn-warning me-2" onClick={() => handleEdit(user)}>Edit</button>
                  <button className="btn btn-danger" onClick={() => handleDelete(user.email)}>Delete</button>
                </td>
              </tr>
          ))}
          </tbody>
        </table>

        <div className="pagination-controls">
          <button
              className="btn btn-secondary me-2"
              onClick={handlePrevPage}
              disabled={currentPage === 1}
          >
            Previous
          </button>

          {Array.from({length: totalPages}, (_, i) => i + 1).map(pageNumber => (
              <button
                  key={pageNumber}
                  className={`btn ${pageNumber === currentPage ? 'btn-primary' : 'btn-outline-primary'} me-2`}
                  onClick={() => handlePageChange(pageNumber)}
              >
                {pageNumber}
              </button>
          ))}

          <button
              className="btn btn-secondary"
              onClick={handleNextPage}
              disabled={currentPage === totalPages}
          >
            Next
          </button>
        </div>

        <p>Page {currentPage} of {totalPages}</p>

        <Modal show={showModal} onHide={() => setShowModal(false)}>
          <Modal.Header closeButton>
            <Modal.Title>{isEdit ? 'Edit User' : 'Add New User'}</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Form onSubmit={isEdit ? handleSave : handleSubmit}>
              <Form.Group>
                <Form.Label>Email</Form.Label>
                <Form.Control
                    type="email"
                    placeholder="Enter email"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    required
                    disabled={isEdit}
                />
              </Form.Group>
              <Form.Group className="mt-2">
                <Form.Label>Active</Form.Label>
                <Form.Control
                    as="select"
                    value={formData.active}
                    onChange={(e) => setFormData({...formData, active: e.target.value})}
                    required
                >
                  <option value="1">Yes</option>
                  <option value="0">No</option>
                </Form.Control>
              </Form.Group>
              <Button variant="success" type="submit" className="mt-3">{isEdit ? 'Save Changes' : 'Add User'}</Button>
            </Form>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => setShowModal(false)}>Close</Button>
          </Modal.Footer>
        </Modal>
      </div>
  );
};

export default UsersTab;