import React, { useState, useRef } from 'react';
import axios from 'axios';
import { Modal, Button } from 'react-bootstrap';
import './BulkAdd.css';
import {toast} from "react-toastify";

const BulkAdd = ({ show, onClose , fetchEbooks }) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedFile, setSelectedFile] = useState(null);
  const [selectedFolder, setSelectedFolder] = useState(null);
  const fileInputRef = useRef(null);
  const folderInputRef = useRef(null);
  const [fileName, setFileName] = useState('');
  const [folderName, setFolderName] = useState('');

  const handleFileChange = (e) => {
    if (e.target.files.length > 0) {
      setSelectedFile(e.target.files[0]);
      setFileName(e.target.files[0].name);
    } else {
      setSelectedFile(null);
      setFileName('');
    }
  };

  const handleFolderChange = (e) => {
  if (e.target.files.length > 0) {
    const folderPath = e.target.files[0].webkitRelativePath;
    const folderName = folderPath.split('/')[0];
    setSelectedFolder(e.target.files);
    setFolderName(folderName);
  } else {
    setSelectedFolder(null);
    setFolderName('');
  }
};

  const handleNext = () => setCurrentStep((prev) => prev + 1);
  const handleBack = () => setCurrentStep((prev) => prev - 1);
  const handleCancel = () => {
    setCurrentStep(1);
    setSelectedFile(null);
    setSelectedFolder(null);
    onClose();
  };

  const handleUpload = () => {
    if (!selectedFile && !selectedFolder) {
      alert('Please select a file or folder first.');
      return;
    }

    const formData = new FormData();
    if (selectedFile) {
      formData.append('excel_file', selectedFile);
    }
    if (selectedFolder) {
      Array.from(selectedFolder).forEach(file => formData.append('pdf_files', file));
    }

    axios.post('/ebooks/bulk/add', formData)
      .then(response => {
        alert(`Bulk upload successful: ${response.data.count} ebooks added.`);
        toast.success(`Bulk upload successful: ${response.data.count} ebooks added.`);
        setCurrentStep(4);
      })
      .catch(err => {
        console.error(err);
        alert('Bulk upload failed. Please try again.');
      });
    fetchEbooks();
  };

  const handleFileButtonClick = () => {
    fileInputRef.current.click();
  };

  const handleFolderButtonClick = () => {
    folderInputRef.current.click();
  };

  return (
    <Modal show={show} onHide={handleCancel} size="lg">
      <Modal.Header closeButton>
        <Modal.Title>Bulk Add Ebooks</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <div className="bulk-add">
          {currentStep === 1 && (
            <div>
              <h2>Step 1: Upload Excel (xlsx) File</h2>
              <p>Please select a excel file containing the ebook metadata.</p>
              <input
                type="file"
                ref={fileInputRef}
                accept=".xlsx"
                onChange={handleFileChange}
              />
              <Button variant="secondary" onClick={handleFileButtonClick}>Choose File</Button>
              {fileName && <p><strong>Selected file:</strong> {fileName}</p>}
              <div className="button-group">
                <Button onClick={handleNext} disabled={!selectedFile}>Next</Button>
                <Button variant="outline-secondary" onClick={handleCancel}>Cancel</Button>
              </div>
            </div>
          )}
          {currentStep === 2 && (
            <div>
              <h2>Step 2: Select Folder with PDF Files</h2>
              <p>Please choose the folder that contains the PDF files for the ebooks.</p>
              <input
                type="file"
                webkitdirectory="true"
                ref={folderInputRef}
                onChange={handleFolderChange}
              />
              <Button variant="secondary" onClick={handleFolderButtonClick}>Choose Folder</Button>
              {folderName && <p><strong>Selected folder:</strong> {folderName}</p>}
              <div className="button-group">
                <Button onClick={handleNext} disabled={!selectedFolder}>Next</Button>
                <Button variant="outline-secondary" onClick={handleBack}>Back</Button>
                <Button variant="outline-secondary" onClick={handleCancel}>Cancel</Button>
              </div>
            </div>
          )}
          {currentStep === 3 && (
            <div>
              <h2>Step 3: Review Your Selections</h2>
              <p><strong>CSV File:</strong> {selectedFile?.name}</p>
              <p><strong>PDF Folder:</strong> {selectedFolder?.length} files selected</p>
              <div className="button-group">
                <Button onClick={handleUpload}>Upload</Button>
                <Button variant="outline-secondary" onClick={handleBack}>Back</Button>
                <Button variant="outline-secondary" onClick={handleCancel}>Cancel</Button>
              </div>
            </div>
          )}
          {currentStep === 4 && (
            <div>
              <h2>Step 4: Upload Complete</h2>
              <p>Your ebooks were successfully uploaded.</p>
              <div className="button-group">
                <Button variant="primary" onClick={handleCancel}>OK</Button>
              </div>
            </div>
          )}
        </div>
      </Modal.Body>
    </Modal>

  );
};

export default BulkAdd;