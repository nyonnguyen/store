const { app, BrowserWindow } = require('electron');
const path = require('path');

// Function to create the window
function createWindow() {
  // Create the browser window
  const win = new BrowserWindow({
    width: 1280,
    height: 1024,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'), // Optional if you want to use preload scripts
      nodeIntegration: true,
    },
  });

  // Load your React app
  win.loadURL('http://localhost:3000');
  
  // Handle the close event
  mainWindow.on('close', (event) => {
    event.preventDefault(); // Prevents the default close behavior

    // Show a confirmation dialog
    const choice = dialog.showMessageBoxSync(mainWindow, {
      type: 'question',
      buttons: ['Yes', 'No'],
      title: 'Confirm',
      message: 'Are you sure you want to quit?',
    });

    // Check if 'Yes' was clicked
    if (choice === 0) {
      // Allow the window to close
      mainWindow = null; // Dereference the window object
      app.quit(); // Quit the application
    }
  });
}

// When Electron has finished initialization, create the window
app.whenReady().then(() => {
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

// Quit the app when all windows are closed
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
