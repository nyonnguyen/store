import uuid

from pydantic import BaseModel, Field
from typing import Optional, Dict
from main.model.status import Status


class KdpModel(BaseModel):

    class Config:
        allow_population_by_field_name = True

    def to_list(self):
        prop_list = []
        for key, value in self.dict().items():
            # ignore id
            if key != 'id':
                prop_list.append(value)
        return prop_list

    def to_tuple(self):
        return tuple(self.to_list())

    def remove_field(self, field_name):
        if hasattr(self, field_name):
            delattr(self, field_name)


# Pydantic model for Ebook
class EbookModel(KdpModel):
    id: Optional[int] = None
    cover_name: str = Field(..., alias='cover_name')
    content_name: str = Field(..., alias='content_name')
    title: str = Field(..., alias='title')
    author_first_name: str = Field(..., alias='author_first_name')
    author_last_name: str = Field(..., alias='author_last_name')
    description: str = Field(..., alias='description')
    category_main: Optional[str] = Field(None, alias='category_main')
    category_sub: Optional[str] = Field(None, alias='category_sub')
    placements: Optional[str] = Field(None, alias='placements')
    keywords: Optional[str] = Field(None, alias='keywords')
    isbn: Optional[str] = Field(None, alias='isbn')
    print_option: Optional[str] = Field(None, alias='print_option')
    trim_size: Optional[str] = Field(None, alias='trim_size')
    bleed: Optional[bool] = Field(False, alias='bleed')
    paper_back_cover: Optional[str] = Field(None, alias='paper_back_cover')
    ai_content: Optional[bool] = Field(False, alias='ai_content')
    price: float = Field(..., alias='price')
    status: Optional[str] = Field(default=Status.NEW.value, alias='status')
    uploaded_by: Optional[str] = None
    task_id: Optional[str] = None
    uploading: bool = False


# Pydantic model for User
class UserModel(KdpModel):
    email: str
    password: str
    key: str
    active: bool = True

    def to_tuple(self):
        return tuple(self.to_list())

class DeviceModel(BaseModel):
    device_name: str
    port: str

class Task(object):
    def __init__(self):
        self.id = str(uuid.uuid4())
        self.status = Status.NEW
        self.message = None
        self.threads = []  # The appium thread that will be started

    def __repr__(self):
        return f"Task({self.id}, {self.status})"

    def __str__(self):
        return f"Task({self.id}, {self.status})"

    def set_status(self, status):
        self.status = status

    def add_thread(self, thread):
        self.threads.append(thread)

    def set_message(self, message):
        self.message = message

class TaskList(object):
    _instance = None

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(TaskList, cls).__new__(cls)
        return cls._instance

    tasks = []

    def add_task(self, task: Task):
        self.tasks.append(task)

    def get_task(self, task_id):
        for task in self.tasks:
            if task.id == task_id:
                return task
        return None

    def remove_task(self, task_id):
        for task in self.tasks:
            if task.id == task_id:
                self.tasks.remove(task)
                return True
        return False

    def set_task(self, task_id, status, message=None):
        for task in self.tasks:
            if task.id == task_id:
                task.set_status(status)
                if message:
                    task.set_message(message)
                return True
        return False

    def add_thread(self, task_id, thread):
        for task in self.tasks:
            if task.id == task_id:
                task.add_thread(thread)
                return True
        return False

    def get_thread(self, task_id):
        for task in self.tasks:
            if task.id == task_id:
                return task.threads
        return None

    def thread_count(self, task_id):
        for task in self.tasks:
            if task.id == task_id:
                return len(task.threads)
        return 0
