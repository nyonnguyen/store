import asyncio
import sqlite3
import time

from fastapi import (
    FastAPI, HTTPException, BackgroundTasks,
    WebSocket, WebSocketDisconnect,
    File, UploadFile, Form
)
from fastapi.middleware.cors import CORSMiddleware
from openpyxl import load_workbook
from web_app.app.models import EbookModel, UserModel, Task, TaskList
from main.helpers.db_helper import DBHelper
from main.helpers.device_helper import query_devices
from upload import start_upload
from utils.files_utils import save_uploaded_file, remove_file, get_base_name
from main.model.status import Status

SCAN_DEVICE_TIMEOUT = 30
app = FastAPI()

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

db_helper = DBHelper()

last_device_scan = time.time()

active_connections: dict[str, WebSocket] = {}

task_list = TaskList()


async def notify_clients(message: str):
    for connection in active_connections.values():
        await connection.send_text(message)


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    active_connections[websocket.client] = websocket
    try:
        while True:
            await websocket.receive_text()  # Keep the connection open
    except WebSocketDisconnect:
        del active_connections[websocket.client]  # Remove disconnected clients


@app.get("/status/")
def get_status():
    return {"status": 200}


@app.get("/devices/")
def scan_devices():
    global last_device_scan
    current_scan_time = time.time() - last_device_scan
    if current_scan_time < SCAN_DEVICE_TIMEOUT:
        return {"message": f"Devices are already scanned within {SCAN_DEVICE_TIMEOUT} seconds", "status": 202}
    try:
        devices = query_devices()
        last_device_scan = time.time()
        return {"message": "Device updated!","devices": [device.to_dict() for device in devices], "status": 200}
    except Exception as e:
        print(f"Failed to scan running devices {e}")
        return {"message": "Failed to scan devices", "status": 400}


# Routes for ebooks
@app.get("/ebooks/")
def get_ebooks():
    conn = db_helper.create_connection()
    ebooks = db_helper.get_all_ebooks()
    conn.close()
    return [row.to_dict() for row in ebooks]


@app.put("/ebooks/upload/add")
def add_upload_ebook(ebook_ids: dict):
    conn = db_helper.create_connection()
    for ebook_id in ebook_ids['ebook_ids']:
        db_helper.set_book_uploading(ebook_id, True)
    conn.close()
    return {"message": "Ebook added to upload"}


@app.put("/ebooks/upload/remove")
def remove_upload_ebook(ebook_ids: dict):
    conn = db_helper.create_connection()
    for ebook_id in ebook_ids['ebook_ids']:
        db_helper.set_book_uploading(ebook_id, False)
    conn.close()
    return {"message": "Ebook added to upload"}


@app.post("/ebooks/delete")
def delete_ebook(ebook_ids: dict):
    ebook_ids = ebook_ids['ebook_ids']
    conn = db_helper.create_connection()
    is_deleted = db_helper.delete_book(ebook_ids)
    conn.close()
    status = 200 if is_deleted else 400
    message = f"{len(ebook_ids)} ebook(s) deleted" if is_deleted else "Delete failed"
    return {"message": message, "status": status}


@app.post("/ebooks/upload")
def upload_ebook(ebook_ids: dict,  background_tasks: BackgroundTasks):
    ebook_ids = ebook_ids['ebook_ids']
    task = Task()
    task_list.add_task(task)
    background_tasks.add_task(do_upload, ebook_ids, task)
    return {"message": f"Ebook uploading sent", "task_id": task.id}


async def do_upload(ebook_ids, task):
    loop = asyncio.get_event_loop()
    try:
        # Execute the blocking task in the background using a thread pool
        result = await loop.run_in_executor(None, start_upload, ebook_ids, task.id)

        print(f"Task {task.id} completed with result: {result}")

    except Exception as e:
        print(f"Error in task {task.id}: {e}")
        task_list.set_task(task.id, Status.FAILED)


@app.post("/ebooks/upload/cancel")
def cancel_upload(task_id: dict):
    task_id = task_id['task_id']
    # Set task status to CANCELLED
    task_list.set_task(task_id, Status.CANCELLED)
    # Check if any thread, terminate it
    thread_count = task_list.thread_count(task_id)
    for thread in task_list.get_thread(task_id):
        thread.terminate()
    return {"message": f"Upload task {task_id} cancelled", "thread_count": thread_count}


# Routes for users
@app.get("/users/")
def get_users():
    conn = db_helper.create_connection()
    users = db_helper.get_users()
    for user in users:
        user.password = None
        user.key = None
    conn.close()
    return [row.to_dict() for row in users]


@app.post("/users/")
def add_user(user: UserModel):
    try:
        conn = db_helper.create_connection()
        db_helper.insert_user(user)
        conn.close()
        message = f"User added - {user.email}"
        status_code = 200
    except Exception as e:
        message = f"Failed to add user - {user.email}. {e}"
        status_code = 400
    return {"message": message, "status": status_code}


@app.put("/users/{email}/{active}")
def update_user(email: str, active: bool):
    try:
        conn = db_helper.create_connection()
        db_helper.update_user(email, active)
        conn.close()
        message = f"User updated - {email}"
        status_code = 200
    except Exception as e:
        message = f"Failed to update user - {email}. {e}"
        status_code = 400
    return {"message": message, "status": status_code}


@app.delete("/users/{email}")
def delete_user(email: str):
    try:
        conn = db_helper.create_connection()
        db_helper.delete_user(email)
        conn.close()
        message = f"User deleted - {email}"
        status_code = 200
    except Exception as e:
        message = f"Failed to delete user - {email}. {e}"
        status_code = 400
    return {"message": message, "status": status_code}


@app.get("/task/{task_id}")
def get_task_status(task_id: str):
    if not task_list.get_task(task_id):
        return {"status": Status.UNDEFINED, "message": "Task not found"}
    status = task_list.get_task(task_id).status
    message = task_list.get_task(task_id).message
    if task_list.get_task(task_id).status == Status.REMAINING_DATA:
        # Set back to IN_PROGRESS if there is remaining data
        task_list.set_task(task_id, Status.IN_PROGRESS)
    return {"status": status, "message": message}


@app.post("/ebooks/bulk/add")
async def add_bulk_ebooks(
        excel_file: UploadFile = File(...),
        pdf_files: list[UploadFile] = File(...)
):
    # Save the Excel file
    excel_file_path = save_uploaded_file(excel_file)

    # Save the PDF files
    pdf_file_paths = []
    for pdf_file in pdf_files:
        pdf_file_name = get_base_name(pdf_file.filename)
        pdf_file.filename = pdf_file_name   # Rename to remove upload folder path
        pdf_file_path = save_uploaded_file(pdf_file)
        pdf_file_paths.append(pdf_file_path)    # Save paths for other purpose

    conn = db_helper.create_connection()
    try:
        workbook = load_workbook(filename=excel_file_path)
        sheet = workbook.active

        # Map Excel headers to EbookModel fields
        headers = [cell.value for cell in sheet[1]]

        field_mapping = {
            "Title": "title",
            "CoverName": "cover_name",
            "ContentName": "content_name",
            "AuthorFirstName": "author_first_name",
            "AuthorLastName": "author_last_name",
            "Description": "description",
            "CategoryMain": "category_main",
            "CategorySub": "category_sub",
            "CategoryPlacements": "placements",
            "Keywords": "keywords",
            "ISBN": "isbn",
            "PrintOption": "print_option",
            "TrimSize": "trim_size",
            "Bleed": "bleed",
            "PaperBackCover": "paper_back_cover",
            "AIContent": "ai_content",
            "Price": "price"
        }

        ebook_data = []
        for row in sheet.iter_rows(min_row=2, values_only=True):
            data = {field_mapping[headers[i]]: value for i, value in enumerate(row) if headers[i] in field_mapping}
            ebook = EbookModel(**data)
            ebook.remove_field("id")
            db_helper.insert_ebook(ebook)
            ebook_data.append(data)
        conn.close()
        return {"message": "Ebooks added", "count": len(ebook_data), "status": 200}
    except Exception as e:
        conn.close()
        raise HTTPException(status_code=400, detail=str(e))
    finally:
        remove_file(excel_file_path)


from fastapi import File, UploadFile

@app.post("/ebooks/")
async def add_or_update_ebook(
    ebook_id: int = Form(None),
    title: str = Form(...),
    author_first_name: str = Form(...),
    author_last_name: str = Form(...),
    cover_name: str = Form(...),
    content_name: str = Form(...),
    category_main: str = Form(...),
    category_sub: str = Form(...),
    placements: str = Form(...),
    keywords: str = Form(None),
    isbn: str = Form(None),
    print_option: str = Form(...),
    trim_size: str = Form(...),
    bleed: str = Form(...),
    paper_back_cover: str = Form(...),
    ai_content: str = Form(...),
    description: str = Form(...),
    status: str = Form(...),
    price: float = Form(...),
    cover_file: UploadFile = File(None),
    content_file: UploadFile = File(None),
    uploading: bool = Form(False),
    task_id: str = Form(None),
):
    ebook = EbookModel(
        title=title,
        author_first_name=author_first_name,
        author_last_name=author_last_name,
        cover_name=cover_name,
        content_name=content_name,
        category_main=category_main,
        category_sub=category_sub,
        placements=placements,
        keywords=(None if keywords == "null" else keywords),
        isbn=(None if isbn == "null" else isbn),
        print_option=print_option,
        trim_size=trim_size,
        bleed=bleed,
        paper_back_cover=paper_back_cover,
        ai_content=ai_content,
        description=description,
        status=status,
        price=price,
        uploading=uploading,
        task_id=(None if task_id == "null" else task_id)
    )

    if cover_file:
        cover_file_path = save_uploaded_file(cover_file)
        ebook.cover_name = cover_file.filename
        print(f"Saved Cover file path: {cover_file_path}")

    if content_file:
        content_file_path = save_uploaded_file(content_file)
        ebook.content_name = content_file.filename
        print(f"Saved Content file path: {content_file_path}")

    conn = db_helper.create_connection()
    if ebook_id:
        is_updated = db_helper.update_book(ebook_id, ebook)
        conn.close()
        status_code = 200 if is_updated else 400
        message = "Ebook updated" if is_updated else "Update failed"
    else:
        new_id = db_helper.insert_ebook(ebook)
        conn.close()
        status_code = 200 if new_id else 400
        message = "Ebook added" if new_id else "Add failed"
        ebook_id = new_id

    return {"message": message, "status": status_code, "id": ebook_id}