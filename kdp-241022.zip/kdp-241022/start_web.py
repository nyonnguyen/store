import platform
import subprocess
import os
import sys
import time
import requests
import uvicorn
from threading import Thread
from utils.process_utils import kill_appium_processes

host = "127.0.0.1"
port = 8090

def start_backend():
    print("Starting backend...")
    config = uvicorn.Config("web_app.app.main_app:app", host=host, port=port, reload=True)
    server = uvicorn.Server(config)
    server.run()
    print("Backend has stopped.")

def wait_for_backend():
    url = f"http://{host}:{port}/status"
    timeout = 60  # Timeout in seconds
    start_time = time.time()
    while time.time() - start_time < timeout:
        try:
            response = requests.get(url)
            if response.status_code == 200:
                print("Backend is running.")
                return True
        except requests.ConnectionError:
            pass
        time.sleep(1)
    print("Failed to start backend within the timeout period.")
    return False

def start_frontend():
    print("Starting frontend...")
    os.chdir("web_app/frontend")
    return subprocess.Popen('npm start', stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)

def start_app():
    print("Starting electron app...")
    # Assume start_frontend() success
    return subprocess.Popen('npm run electron', stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)

def read_process_output(process):
    while True:
        output = process.stdout.readline()
        if output == b'' and process.poll() is not None:
            break
        if output:
            print(output.decode().strip())

def read_process_err(process):
    while True:
        output = process.stderr.readline()
        if output == b'' and process.poll() is not None:
            break
        if output:
            print(output.decode().strip())
            print("[Front End]: Failed to start frontend")
            sys.exit(1)

def clean_up_previous_run_data():
    file_path = 'cookies.json'
    if os.path.exists(file_path):
        os.remove(file_path)
    else:
        print(f"File {file_path} does not exist")

    # clean up appium processes from previous execution
    kill_appium_processes()

if __name__ == '__main__':
    clean_up_previous_run_data()

    try:
        backend_thread = Thread(target=start_backend)
        backend_thread.start()

        if wait_for_backend():
            frontend_process = start_frontend()
            app_thread = Thread(target=start_app)
            app_thread.start()

            frontend_thread_out = Thread(target=read_process_output, args=(frontend_process,))
            frontend_thread_err = Thread(target=read_process_err, args=(frontend_process,))

            frontend_thread_out.start()
            frontend_thread_err.start()

            while True:
                time.sleep(1)
    except KeyboardInterrupt:
        print("Terminating processes...")
        clean_up_previous_run_data()