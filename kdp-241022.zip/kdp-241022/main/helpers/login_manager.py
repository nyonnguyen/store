import time
from main.helpers.cookie_helper import CookieManager

class LoginSessionManager:
    def __init__(self, driver, device, current_user, login_function):
        self.driver = driver
        self.device = device
        self.current_user = current_user
        self._login_function = login_function
        self.cookie_manager = CookieManager()

    def login(self):
        cookies = self.cookie_manager.get_cookies(self.current_user.email)
        if cookies:
            print(f"User {self.current_user.email} has cookies")
            current_time = time.time()
            cookies_added = False  # Track if at least one valid cookie is added
            for cookie in cookies:
                if cookie.get('expiry') and cookie['expiry'] > current_time:
                    self.driver.add_cookie(cookie)
                    cookies_added = True
                else:
                    print("Cookie is expired and will not be added.")
                    cookies_added = False

            if cookies_added:
                print("Cookie added successfully.")
            else:
                self._valid_login()
        else:
            self._valid_login()

    def _valid_login(self):
        self.driver.delete_all_cookies()
        print(f"Logging in new user: {self.current_user.email}")
        self._login_function(self.driver, self.device, self.current_user)  # Pass to the external login function
        self.cookie_manager.save_cookies(self.current_user.email, self.driver.get_cookies())
