# Define the Device model
class Device:
    def __init__(self, device_name, udid, platform_version, port=None):
        self.device_name = device_name
        self.udid = udid
        self.platform_version = platform_version
        self.port = port

    def to_dict(self):
        """Convert the Device object to a dictionary for saving to JSON."""
        return {
            "deviceName": self.device_name,
            "udid": self.udid,
            "platformVersion": self.platform_version,
            "port": self.port
        }

    def __repr__(self):
        return f"Device(device_name={self.device_name}, udid={self.udid}, platform_version={self.platform_version}, port={self.port})"
