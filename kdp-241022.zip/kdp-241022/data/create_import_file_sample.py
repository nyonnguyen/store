import openpyxl
from openpyxl import Workbook

# Create a new workbook and select the active worksheet
wb = Workbook()
ws = wb.active

# Define the headers based on the EbookModel attributes
headers = [
    "Title", "AuthorFirstName", "AuthorLastName", "Description", "CategoryMain",
    "CategorySub", "CategoryPlacements", "Keywords", "ISBN", "PrintOption",
    "TrimSize", "Bleed", "PaperBackCover", "AIContent", "Price", "Status",
    "UploadedBy", "TaskId", "Uploading"
]

# Add the headers to the first row
ws.append(headers)

# Add an example row of data
example_data = [
    "Example Book", "John", "Doe", "A great book", "Fiction", "Mystery", "Shelf 1",
    "book, read", "1234567890", "Option 1", "Size 1", "Yes", "Cover 1", "No",
    9.99, "New", "admin", 1, False
]

ws.append(example_data)

# Save the workbook to a file
wb.save("example_ebooks.xlsx")