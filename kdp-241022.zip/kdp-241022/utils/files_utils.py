import os
import shutil
from fastapi import UploadFile
from utils.path_utils import get_path

from main.helpers.config_reader import ConfigReader

path = ConfigReader('configs/env.json').get('env')


UPLOAD_DIR = get_path(path['UPLOAD_PATH'])

def save_uploaded_file(file: UploadFile) -> str:
    # Ensure the upload directory exists
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    file_path = os.path.join(UPLOAD_DIR, file.filename)
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    return file_path

def remove_file(file_path):
    if os.path.exists(file_path):
        os.remove(file_path)

def get_base_name(file):
    return os.path.basename(file)