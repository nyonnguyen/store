import React, { useState, useRef } from 'react';
import axios from 'axios';
import { Button } from 'react-bootstrap';
import './BulkAdd.css';

const BulkAdd = () => {
  const [selectedFiles, setSelectedFiles] = useState(null);
  const [fileName, setFileName] = useState('');
  const fileInputRef = useRef(null);

  const handleFileChange = (e) => {
    if (e.target.files.length > 0) {
      setSelectedFiles(e.target.files[0]);
      setFileName(e.target.files[0].name);
    } else {
      setSelectedFiles(null);
      setFileName('');
    }
  };

  const handleBulkAdd = () => {
    if (!selectedFiles) {
      alert('Please select a file first.');
      return;
    }

    const formData = new FormData();
    formData.append('file', selectedFiles);

    axios.post('/ebooks/bulk/add', formData)
      .then(response => {
        alert(`Bulk upload successful: ${response.data.count} ebooks added.`);
      })
      .catch(err => {
        console.error(err);
        alert('Bulk upload failed. Please try again.');
      });
  };

  const handleButtonClick = () => {
    fileInputRef.current.click();
  };

  return (
    <div className="bulk-add">
      <input
        type="file"
        ref={fileInputRef}
        style={{ display: 'none' }}
        onChange={handleFileChange}
      />
      <Button variant="secondary" onClick={handleButtonClick}>Select File</Button>
      {fileName && <p>Selected file: {fileName}</p>}
      <Button variant="secondary" onClick={handleBulkAdd}>Bulk Add</Button>
    </div>
  );
};

export default BulkAdd;