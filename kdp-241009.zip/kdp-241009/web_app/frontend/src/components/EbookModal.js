import React, { useState, useEffect } from 'react';
import { Modal, Form, Button, Row, Col } from 'react-bootstrap';
import './EbookModal.css'; // Import the CSS file

const EbookModal = ({ show, handleClose, handleSubmit, formData, setFormData, isEdit }) => {
  const [coverFile, setCoverFile] = useState(null);
  const [contentFile, setContentFile] = useState(null);

  useEffect(() => {
    if (!isEdit) {
      setFormData({
        title: '',
        author_first_name: '',
        author_last_name: '',
        cover_name: '',
        content_name: '',
        category_main: '',
        category_sub: '',
        placements: '',
        keywords: '',
        isbn: '',
        print_option: 'BW_WHITE',
        trim_size: '6 x 9',
        bleed: '0',
        paper_back_cover: 'matte',
        ai_content: '0',
        description: '',
        status: 'NEW',
        price: 0.0
      });
    }
  }, [isEdit, setFormData]);

  const isValidFormData = (data) => {
    return data && typeof data === 'object' && !Array.isArray(data);
  };

  if (!isValidFormData(formData)) {
    return <div>Error: Invalid form data</div>;
  }

  const handleFileChange = (e, setFile, fieldName) => {
    const file = e.target.files[0];
    setFile(file);
    if (file) {
      setFormData(prevFormData => ({
        ...prevFormData,
        [fieldName]: file.name
      }));
    }
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    const formDataWithFiles = new FormData();
    Object.keys(formData).forEach(key => {
      formDataWithFiles.append(key, formData[key]);
    });
    if (coverFile) {
      formDataWithFiles.append('cover_file', coverFile);
    }
    if (contentFile) {
      formDataWithFiles.append('content_file', contentFile);
    }
    handleSubmit(formDataWithFiles);
  };

  return (
    <Modal show={show} onHide={handleClose} size="lg" className="ebook-modal">
      <Modal.Header closeButton>
        <Modal.Title>{isEdit ? 'Edit eBook' : 'Add eBook'}</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form onSubmit={handleFormSubmit}>
          <Row>
            <Col>
              <Form.Group controlId="formTitle">
                <Form.Label>Title *</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter title"
                  value={formData.title || ""}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  required
                />
              </Form.Group>
            </Col>
          </Row>

          <Row>
            <Col>
              <Form.Group controlId="formAuthorFirstName">
                <Form.Label>Author First Name *</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter first name"
                  value={formData.author_first_name || ""}
                  onChange={(e) => setFormData({ ...formData, author_first_name: e.target.value })}
                  required
                />
              </Form.Group>
            </Col>
            <Col>
              <Form.Group controlId="formAuthorLastName">
                <Form.Label>Author Last Name *</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter last name"
                  value={formData.author_last_name || ""}
                  onChange={(e) => setFormData({ ...formData, author_last_name: e.target.value })}
                  required
                />
              </Form.Group>
            </Col>
          </Row>

          <Row>
            <Col>
              <Form.Group controlId="formCoverFile">
                <Form.Label>Cover Name</Form.Label>
                <Form.Control
                  type="file"
                  accept="application/pdf"
                  onChange={(e) => handleFileChange(e, setCoverFile, 'cover_name')}
                />
                {formData.cover_name && <Form.Text className="text-muted">Current file: {formData.cover_name}</Form.Text>}
              </Form.Group>
            </Col>
            <Col>
              <Form.Group controlId="formContentFile">
                <Form.Label>Content Name</Form.Label>
                <Form.Control
                  type="file"
                  accept="application/pdf"
                  onChange={(e) => handleFileChange(e, setContentFile, 'content_name')}
                />
                {formData.content_name && <Form.Text className="text-muted">Current file: {formData.content_name}</Form.Text>}
              </Form.Group>
            </Col>
          </Row>

          <Row>
            <Col>
              <Form.Group controlId="formCategoryMain">
                <Form.Label>Main Category *</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter main category"
                  value={formData.category_main || ""}
                  onChange={(e) => setFormData({ ...formData, category_main: e.target.value })}
                  required
                />
              </Form.Group>
            </Col>
            <Col>
              <Form.Group controlId="formCategorySub">
                <Form.Label>Sub Category (Optional)</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter sub category"
                  value={formData.category_sub || ""}
                  onChange={(e) => setFormData({ ...formData, category_sub: e.target.value })}
                />
              </Form.Group>
            </Col>
          </Row>
          <Row>
            <Col>
              <Form.Group controlId="formPlacements">
                <Form.Label>Placements *</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter placements"
                  value={formData.placements || ""}
                  onChange={(e) => setFormData({ ...formData, placements: e.target.value })}
                  required
                />
              </Form.Group>
            </Col>
            <Col>
              <Form.Group controlId="formKeywords">
                <Form.Label>Keywords (Optional)</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter keywords"
                  value={formData.keywords || ""}
                  onChange={(e) => setFormData({ ...formData, keywords: e.target.value })}
                />
              </Form.Group>
            </Col>
          </Row>
          <Row>
            <Col>
              <Form.Group controlId="formAiContent">
                <Form.Label>AI Content (Optional)</Form.Label>
                <Form.Control
                  as="select"
                  value={formData.ai_content || '0'}
                  onChange={(e) => setFormData({ ...formData, ai_content: e.target.value })}
                  required
                >
                  <option value="0">No</option>
                  <option value="1">Yes</option>
                </Form.Control>
              </Form.Group>
            </Col>
            <Col>
              <Form.Group controlId="formIsbn">
                <Form.Label>ISBN (Optional)</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter ISBN"
                  value={formData.isbn || ""}
                  onChange={(e) => setFormData({ ...formData, isbn: e.target.value })}
                />
              </Form.Group>
            </Col>
          </Row>

          <Row>
            <Col>
              <Form.Group controlId="formPrintOption">
                <Form.Label>Print Option (Optional)</Form.Label>
                <Form.Control
                  as="select"
                  value={formData.print_option || 'BW_WHITE'}
                  onChange={(e) => setFormData({ ...formData, print_option: e.target.value })}
                >
                  <option value="COLOR_COLOR">COLOR_COLOR</option>
                  <option value="COLOR_WHITE">COLOR_WHITE</option>
                  <option value="BW_CREAM">BW_CREAM</option>
                  <option value="BW_WHITE">BW_WHITE</option>
                </Form.Control>
              </Form.Group>
            </Col>
            <Col>
              <Form.Group controlId="formTrimSize">
                <Form.Label>Trim Size (Optional)</Form.Label>
                <Form.Control
                  as="select"
                  value={formData.trim_size || '6 x 9'}
                  onChange={(e) => setFormData({ ...formData, trim_size: e.target.value })}
                >
                  <option value="5 x 8">5 x 8</option>
                  <option value="6 x 9">6 x 9</option>
                  <option value="8.5 x 11">8.5 x 11</option>
                </Form.Control>
              </Form.Group>
            </Col>
          </Row>

          <Row>
            <Col>
              <Form.Group controlId="formBleed">
                <Form.Label>Bleed (Optional)</Form.Label>
                <Form.Control
                  as="select"
                  value={formData.bleed || '0'}
                  onChange={(e) => setFormData({ ...formData, bleed: e.target.value })}
                >
                  <option value="0">No</option>
                  <option value="1">Yes</option>
                </Form.Control>
              </Form.Group>
            </Col>
            <Col>
              <Form.Group controlId="formPaperBackCover">
                <Form.Label>Paper Back Cover (Optional)</Form.Label>
                <Form.Control
                  as="select"
                  value={formData.paper_back_cover || 'matte'}
                  onChange={(e) => setFormData({ ...formData, paper_back_cover: e.target.value })}
                >
                  <option value="matte">MATTE</option>
                  <option value="glossy">GLOSSY</option>
                </Form.Control>
              </Form.Group>
            </Col>
          </Row>
          <Row>
            <Col>
              <Form.Group controlId="formDescription">
                <Form.Label>Description *</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Description"
                  value={formData.description || ""}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                />
              </Form.Group>
            </Col>
          </Row>
          <Row>
            <Col>
              <Form.Group controlId="formStatus">
                <Form.Label>Status *</Form.Label>
                <Form.Control
                  as="select"
                  value={formData.status || 'NEW'}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                  required
                >
                  <option value="NEW">NEW</option>
                  <option value="SKIPPED">SKIPPED</option>
                </Form.Control>
              </Form.Group>
            </Col>
            <Col>
              <Form.Group controlId="formPrice">
                <Form.Label>Price *</Form.Label>
                <Form.Control
                  type="number"
                  step="0.01"
                  placeholder="Enter price"
                  value={formData.price || 0.0}
                  onChange={(e) => setFormData({ ...formData, price: parseFloat(e.target.value) })}
                  required
                />
              </Form.Group>
            </Col>
          </Row>
          <Modal.Footer>
            <Button variant="success" type="submit">
              {isEdit ? 'Save Changes' : 'Add eBook'}
            </Button>
          </Modal.Footer>
        </Form>
      </Modal.Body>
    </Modal>
  );
};

export default EbookModal;