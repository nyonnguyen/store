import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Form, Button, OverlayTrigger, Tooltip } from 'react-bootstrap';
import BulkAdd from './BulkAdd';
import EbookModal from './EbookModal';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import UploadEbookTable from './UploadEbookTable';
import './EbooksTab.css';

const EbooksTab = () => {
  const [ebooks, setEbooks] = useState([]);
  const [editableEbook, setEditableEbook] = useState(null);
  const [formData, setFormData] = useState({
    title: '', author_first_name: '', author_last_name: '', price: 0, status: 'NEW',
    cover_name: '', content_name: '', description: '', category_main: '', category_sub: '',
    placements: '', keywords: '', isbn: '', print_option: '', trim_size: '', bleed: false,
    paper_back_cover: '', ai_content: false, uploaded_by: '', task_id: '', uploading: false,
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({ status: '', price_range: [0, 100] });
  const [showModal, setShowModal] = useState(false);
  const [isEdit, setIsEdit] = useState(false);
  const [selectedEbooks, setSelectedEbooks] = useState(new Set());
  const [currentPage, setCurrentPage] = useState(1);
  const [showMainTable, setShowMainTable] = useState(true);
  const itemsPerPage = 10;

  useEffect(() => {
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css';
    document.head.appendChild(link);
  }, []);

  const fetchEbooks = () => {
    axios.get('/ebooks/')
      .then(res => setEbooks(res.data))
      .catch(err => console.error(err));
    clearSelectedEbooks();
  };

  useEffect(() => {
    fetchEbooks();
    const interval = setInterval(fetchEbooks, 30000);
    return () => clearInterval(interval);
  }, []);

  const handleEdit = (ebook) => {
    setEditableEbook(ebook);
    setFormData({ ...ebook });
    setIsEdit(true);
    setShowModal(true);
    clearSelectedEbooks();
  };

  const handleSave = (formDataWithFiles) => {
    console.log("Handle Save")
    if (formDataWithFiles.has('ebook_id')) {
      formDataWithFiles.delete('ebook_id');
    }
    // print debug data from formDataWithFiles
    formDataWithFiles.append('ebook_id', editableEbook.id);
    for (var pair of formDataWithFiles.entries()) {
        console.log(pair[0]+ ': ' + pair[1]);
    }
    axios.post(`/ebooks/`, formDataWithFiles, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    })
    .then(() => {
      fetchEbooks();
      setShowModal(false);
      clearSelectedEbooks();
    })
    .catch(err => console.error(err));
  };

  const handleAdd = (formDataWithFiles) => {
    // print debug data from formDataWithFiles
    for (var pair of formDataWithFiles.entries()) {
        console.log(pair[0]+ ': ' + pair[1]);
    }
    axios.post('/ebooks/', formDataWithFiles, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    })
    .then(({ data: { message, status, id } }) => {
      if (status === 200) {
        toast.success("New ebook added successfully! ID: " + id);
        fetchEbooks();
        setShowModal(false);
        clearSelectedEbooks();
      } else {
        toast.error('Failed to add new ebook.');
      }
    })
    .catch(err => {
      console.error(err);
      toast.error('Failed to add new ebook.');
    });
  };

  const handleCancel = () => {
    setShowModal(false);
    clearSelectedEbooks();
  };

  const handleDelete = (id) => {
    if (window.confirm('Are you sure you want to delete this eBook?')) {
      axios.post(`/ebooks/delete`, {ebook_ids: [id]})
        .then(({ data: { message, status } }) => {
          if (status === 200) {
            toast.success('eBook deleted successfully.');
            fetchEbooks();
          } else {
            toast.error('Failed to delete eBook.');
          }
        })
        .catch(err => {
          console.error(err);
          toast.error('Failed to delete eBook.');
        });
      clearSelectedEbooks();
    }
  };

  const handleBulkDelete = () => {
    if (selectedEbooks.size === 0) {
      alert("Please select at least one eBook to delete.");
      return;
    }

    const idsToDelete = Array.from(selectedEbooks);
    if (window.confirm('Are you sure you want to delete the selected eBooks?')) {
      axios.post(`/ebooks/delete`, {ebook_ids: idsToDelete})
        .then(({ status }) => {
          if (status === 200) {
            toast.success('eBook deleted successfully.');
            fetchEbooks();
          } else {
            toast.error('Failed to delete eBook.');
          }
        })
        .catch(err => {
          console.error(err);
          toast.error('Failed to delete eBook.');
        });
      clearSelectedEbooks();
    }
  };

  const handleSelectEbook = (id) => {
    setSelectedEbooks(prev => {
      const newSelection = new Set(prev);
      newSelection.has(id) ? newSelection.delete(id) : newSelection.add(id);
      return newSelection;
    });
  };

  const handleCheckAll = (checked) => {
    setSelectedEbooks(checked ? new Set(filteredEbooks.map(ebook => ebook.id)) : new Set());
  };

  const handleAddToUpload = () => {
    const ebookIds = Array.from(selectedEbooks);
    axios.put(`/ebooks/upload/add`, { ebook_ids: ebookIds })
      .then(response => {
        console.log('Add to upload response:', response.data);
        fetchEbooks();
      })
      .catch(error => console.error('Error adding to upload:', error));
    clearSelectedEbooks();
  };

  const handleSingleAddToUpload = (ebook_id) => {
    axios.put(`/ebooks/upload/add`, { ebook_ids: [ebook_id] })
      .then(response => {
        console.log('Add to upload response:', response.data);
        fetchEbooks();
      })
      .catch(error => console.error('Error adding to upload:', error));
    clearSelectedEbooks();
  };

  const clearSelectedEbooks = () => setSelectedEbooks(new Set());

  const filteredEbooks = ebooks.filter(ebook => (
    (ebook.status === filters.status || !filters.status) &&
    ebook.price >= filters.price_range[0] && ebook.price <= filters.price_range[1] &&
    ebook.title.toLowerCase().includes(searchQuery.toLowerCase())
  ));

  const currentEbooks = filteredEbooks.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);
  const totalPages = Math.ceil(filteredEbooks.length / itemsPerPage);

  return (
      <div className="container mt-4 ebook-container">
        <h3>eBooks List</h3>
        <div className="d-flex justify-content-between mb-3">
          <div>
            <button className="btn btn-primary mr-2" onClick={fetchEbooks}>Refresh</button>
            <button className="btn btn-success mr-2" onClick={() => {
              setIsEdit(false);
              setShowModal(true);
            }}>Add New
            </button>
            <button className="btn btn-danger mr-2" onClick={handleBulkDelete}>Delete Selected</button>
          </div>
          <div>
            <BulkAdd/>
          </div>
        </div>
        <div className="d-flex mb-3">
          <button className="btn btn-primary mr-2" onClick={handleAddToUpload}>Add to Upload</button>
        </div>
        <div className="row mb-3">
          <div className="col-md-3">
            <Form.Group controlId="filterStatus">
              <Form.Label>Status Filter</Form.Label>
              <Form.Control as="select" value={filters.status}
                            onChange={(e) => setFilters({...filters, status: e.target.value})}>
                <option value="">All</option>
                <option value="NEW">NEW</option>
                <option value="IN_PROGRESS">IN_PROGRESS</option>
                <option value="DONE">DONE</option>
                <option value="FAILED">FAILED</option>
                <option value="SKIPPED">SKIPPED</option>
              </Form.Control>
            </Form.Group>
          </div>
          <div className="col-md-3">
            <Form.Group controlId="searchBox">
              <Form.Label>Search eBooks</Form.Label>
              <Form.Control type="text" placeholder="Search by title" value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}/>
            </Form.Group>
          </div>
        </div>
        <Button onClick={() => setShowMainTable(prev => !prev)}>
          {showMainTable ? 'Hide Table' : 'Show Table'}
        </Button>
        {showMainTable && (
            <table className="table table-bordered ebooks-tab-table resizable-table">
              <thead>
              <tr>
                <th>
                  <input type="checkbox" onChange={(e) => handleCheckAll(e.target.checked)}
                         checked={ebooks.length > 0 && ebooks.every(ebook => selectedEbooks.has(ebook.id))}/>
                </th>
                <th>Actions</th>
                <th>Title</th>
                <th>Author</th>
                <th>Price</th>
                <th>Status</th>
                <th>Cover Name</th>
                <th>Content Name</th>
                <th>Description</th>
                <th>Main Category</th>
                <th>Sub Category</th>
                <th>Placements</th>
                <th>Keywords</th>
                <th>ISBN</th>
                <th>Print Option</th>
                <th>Trim Size</th>
                <th>Bleed</th>
                <th>Paper Back Cover</th>
                <th>AI Content</th>
                <th>Uploaded By</th>
              </tr>
              </thead>
              <tbody>
              {currentEbooks.map((ebook) => (
                  <tr key={ebook.id} className={`status-${ebook.status.toLowerCase().replace('_', '-')}`}>
                    <td>
                      <input type="checkbox" checked={selectedEbooks.has(ebook.id)}
                             onChange={() => handleSelectEbook(ebook.id)}/>
                    </td>
                    <td>
                      <OverlayTrigger placement="top" overlay={<Tooltip id={`tooltip-add-${ebook.id}`}>Add</Tooltip>}>
                        <button className="btn btn-success btn-sm mr-2 btn-small"
                                onClick={() => handleSingleAddToUpload(ebook.id)}>
                          <i className="fas fa-plus icon-small"></i>
                        </button>
                      </OverlayTrigger>
                      <OverlayTrigger placement="top" overlay={<Tooltip id={`tooltip-edit-${ebook.id}`}>Edit</Tooltip>}>
                        <button className="btn btn-warning btn-sm mr-2 btn-small" onClick={() => handleEdit(ebook)}>
                          <i className="fas fa-edit icon-small"></i>
                        </button>
                      </OverlayTrigger>
                      <OverlayTrigger placement="top"
                                      overlay={<Tooltip id={`tooltip-delete-${ebook.id}`}>Delete</Tooltip>}>
                        <button className="btn btn-danger btn-sm btn-small" onClick={() => handleDelete(ebook.id)}>
                          <i className="fas fa-trash icon-small"></i>
                        </button>
                      </OverlayTrigger>
                    </td>
                    <td>{ebook.title || 'N/A'}</td>
                    <td>{ebook.author_first_name || 'N/A'} {ebook.author_last_name || 'N/A'}</td>
                    <td>${ebook.price ? ebook.price.toFixed(2) : '0.00'}</td>
                    <td>{ebook.status || 'N/A'}</td>
                    <td>{ebook.cover_name || 'N/A'}</td>
                    <td>{ebook.content_name || 'N/A'}</td>
                    <td>{ebook.description ? (ebook.description.length > 20 ? `${ebook.description.substring(0, 20)}...` : ebook.description) : 'N/A'}</td>
                    <td>{ebook.category_main || 'N/A'}</td>
                    <td>{ebook.category_sub || 'N/A'}</td>
                    <td>{ebook.placements || 'N/A'}</td>
                    <td>{ebook.keywords ? (ebook.keywords.length > 10 ? `${ebook.keywords.substring(0, 10)}...` : ebook.keywords) : 'N/A'}</td>
                    <td>{ebook.isbn || 'N/A'}</td>
                    <td>{ebook.print_option || 'N/A'}</td>
                    <td>{ebook.trim_size || 'N/A'}</td>
                    <td>{ebook.bleed ? 'Yes' : 'No'}</td>
                    <td>{ebook.paper_back_cover || 'N/A'}</td>
                    <td>{ebook.ai_content ? 'Yes' : 'No'}</td>
                    <td>{ebook.uploaded_by || 'N/A'}</td>
                  </tr>
              ))}
              </tbody>
            </table>
        )}
        <div className="pagination">
          <Button onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}>Previous</Button>
          <span>{currentPage} / {totalPages}</span>
          <Button onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                  disabled={currentPage === totalPages}>Next</Button>
          <span>Total: {filteredEbooks.length}</span>
        </div>


        <EbookModal
            show={showModal}
            handleClose={handleCancel}
            handleSubmit={isEdit ? handleSave : handleAdd}
            formData={formData}
            setFormData={setFormData}
            isEdit={isEdit}
        />
        <UploadEbookTable ebooks={ebooks.filter(ebook => ebook.uploading)} fetchEbooks={fetchEbooks}/>

        <ToastContainer/>
      </div>
  );
};

export default EbooksTab;