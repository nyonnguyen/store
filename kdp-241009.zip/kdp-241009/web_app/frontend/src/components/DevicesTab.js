import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './DevicesTab.css';

const DevicesTab = () => {
  const [devices, setDevices] = useState([]);
  const [countdown, setCountdown] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Pagination states
  const [currentPage, setCurrentPage] = useState(1);
  const [devicesPerPage] = useState(5); // Number of devices per page (you can adjust this)

  const fetchDevices = () => {
    axios.get('/devices/')
      .then(res => {
        setDevices(res.data);
        setIsRefreshing(false);  // Re-enable button after fetching data
        setCountdown(30);        // Start countdown from 30 seconds
      })
      .catch(err => {
        console.error(err);
        setIsRefreshing(false);  // Re-enable button even if there's an error
      });
  };

  // Countdown effect to handle button disabling
  useEffect(() => {
    let timer;
    if (countdown > 0) {
      timer = setTimeout(() => setCountdown(countdown - 1), 1000);  // Decrement countdown every second
    }
    return () => clearTimeout(timer);  // Clear timer when the component unmounts or countdown changes
  }, [countdown]);

  // Auto-refresh devices every 5 minutes
  useEffect(() => {
    fetchDevices();
    const interval = setInterval(fetchDevices, 300000); // Auto refresh every 5 minutes (300000ms)
    return () => clearInterval(interval);
  }, []);

  // Handle the button click to refresh manually
  const handleRefreshClick = () => {
    if (!isRefreshing) {
      setIsRefreshing(true);  // Disable button
      fetchDevices();         // Fetch devices and start countdown
    }
  };

  // Pagination logic
  const indexOfLastDevice = currentPage * devicesPerPage;
  const indexOfFirstDevice = indexOfLastDevice - devicesPerPage;
  const currentDevices = devices.slice(indexOfFirstDevice, indexOfLastDevice);

  const totalPages = Math.ceil(devices.length / devicesPerPage);

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  return (
    <div className="container mt-4">
      <h3>Scanned Devices List</h3>
      <button
        className="btn btn-primary mb-3"
        onClick={handleRefreshClick}
        disabled={isRefreshing || countdown > 0}
      >
        {countdown > 0 ? `Refresh (${countdown}s)` : 'Refresh'}
      </button>

      <p>Total Devices: {devices.length}</p>  {/* Display total number of devices */}

      <table className="table table-bordered">
        <thead>
          <tr>
            <th>Device Name</th>
            <th>UDID</th>
            <th>Platform Version</th>
            <th>Port</th>
          </tr>
        </thead>
        <tbody>
          {currentDevices.map((device) => (
            <tr key={device.deviceName}>
              <td>{device.deviceName}</td>
              <td>{device.udid}</td>
              <td>{device.platformVersion}</td>
              <td>{device.port}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Pagination controls */}
      <div className="pagination-controls">
        <button
          className="btn btn-secondary me-2"
          onClick={handlePrevPage}
          disabled={currentPage === 1}
        >
          Previous
        </button>

        {Array.from({ length: totalPages }, (_, i) => i + 1).map(pageNumber => (
          <button
            key={pageNumber}
            className={`btn ${pageNumber === currentPage ? 'btn-primary' : 'btn-outline-primary'} me-2`}
            onClick={() => handlePageChange(pageNumber)}
          >
            {pageNumber}
          </button>
        ))}

        <button
          className="btn btn-secondary"
          onClick={handleNextPage}
          disabled={currentPage === totalPages}
        >
          Next
        </button>
      </div>

      <p>Page {currentPage} of {totalPages}</p> {/* Display current page and total pages */}
    </div>
  );
};

export default DevicesTab;
