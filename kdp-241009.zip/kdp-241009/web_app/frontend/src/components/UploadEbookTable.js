import React, { useState, useRef } from 'react';
import './UploadEbookTable.css';
import { Button, Form, Spinner, Table } from 'react-bootstrap';
import axios from 'axios';
import {toast} from "react-toastify";

const UploadEbookTable = ({ ebooks, fetchEbooks }) => {
  const [filters, setFilters] = useState({ status: '', price_range: [0, 100] });
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedEbooks, setSelectedEbooks] = useState(new Set());
  const [currentPage, setCurrentPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const itemsPerPage = 10;

  const handleStartUpload = () => {
    setLoading(true);
    const ebookIds = ebooks.map(ebook => ebook.id);
    axios.post('/ebooks/upload', { ebook_ids: ebookIds })
      .then(({ data: { message, task_id } }) => {
        console.log('Upload request sent:', message);
        toast.success("Sending " + ebookIds.length + " to upload... \n\rTask ID: " + task_id)
        checkTaskStatus(task_id);
      })
      .catch(error => {
        console.error('Error uploading ebooks:', error);
        toast.error("Error uploading ebooks: " + error)
        setLoading(false);

      });
  };

  const checkTaskStatus = (task_id) => {
    const intervalId = setInterval(() => {
      axios.get(`/tasks/${task_id}`)
        .then(({ data: { message, status } }) => {
          console.log(`Task Status for ${task_id}:`, status);
          if (status === 'COMPLETED' || status === 'FAILED') {
            clearInterval(intervalId);
            setLoading(false);
            if (status === 'COMPLETED') {
              toast.success("Task completed successfully!")
              fetchEbooks();
            } else {
              toast.error("Task failed!\n" + message)
            }
          }
        })
        .catch(error => {
          console.error('Error checking task status:', error);
            toast.error("Error checking task status: " + error)
          clearInterval(intervalId);
          setLoading(false);
        });
    }, 5000);
  };

  const handleCancelUpload = () => {
    const ebookIds = ebooks.map(ebook => ebook.id);
    axios.post('/ebooks/cancel', { ids: ebookIds })
      .then(response => console.log('Upload canceled:', response.data))
      .catch(error => console.error('Error canceling upload:', error));
  };

  const handleRemoveSelected = () => {
    if (selectedEbooks.size === 0) {
      alert("Please select at least one eBook to remove.");
      return;
    }
    const ebookIds = Array.from(selectedEbooks);
    setLoading(true);
    setSelectedEbooks(new Set());
    axios.put('/ebooks/upload/remove', { ebook_ids: ebookIds })
      .then(response => {
        console.log('Remove from upload response:', response.data);
        fetchEbooks();
        setLoading(false);
      })
      .catch(error => {
        console.error('Error removing from upload:', error);
        setLoading(false);
      });
  };

  const handleSelectEbook = (id) => {
    setSelectedEbooks(prev => {
      const newSelection = new Set(prev);
      newSelection.has(id) ? newSelection.delete(id) : newSelection.add(id);
      return newSelection;
    });
  };

  const handleCheckAll = (checked) => {
    setSelectedEbooks(checked ? new Set(ebooks.map(ebook => ebook.id)) : new Set());
  };

  const handleClearDone = async () => {
    const doneEbookIds = ebooks.filter(ebook => ebook.status === 'DONE').map(ebook => ebook.id);
    if (doneEbookIds.length > 0) {
      try {
        await axios.put('/ebooks/upload/remove', { ebook_ids: doneEbookIds });
        fetchEbooks(); // Refresh the ebook list
      } catch (error) {
        console.error('Error clearing done ebooks:', error);
      }
    } else {
      console.log('No DONE ebooks to clear.');
    }
  };

  const filteredEbooks = ebooks.filter(ebook => (
    (ebook.status === filters.status || !filters.status) &&
    ebook.price >= filters.price_range[0] && ebook.price <= filters.price_range[1] &&
    ebook.title.toLowerCase().includes(searchQuery.toLowerCase())
  ));

  const totalPages = Math.ceil(filteredEbooks.length / itemsPerPage);
  const currentEbooks = filteredEbooks.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  return (
    <div className="container mt-4">
      <h3>Uploading eBooks</h3>
      <div className="row mb-3">
        <div className="col-md-3">
          <Form.Group controlId="filterStatus">
            <Form.Label>Status Filter</Form.Label>
            <Form.Control as="select" value={filters.status} onChange={(e) => setFilters({ ...filters, status: e.target.value })}>
              <option value="">All</option>
              <option value="NEW">NEW</option>
              <option value="IN_PROGRESS">IN_PROGRESS</option>
              <option value="DONE">DONE</option>
              <option value="FAILED">FAILED</option>
              <option value="SKIPPED">SKIPPED</option>
            </Form.Control>
          </Form.Group>
        </div>
        <div className="col-md-3">
          <Form.Group controlId="searchBox">
            <Form.Label>Search eBooks</Form.Label>
            <Form.Control type="text" placeholder="Search by title" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
          </Form.Group>
        </div>
      </div>
      <div className="d-flex mb-3">
        <Button className="mr-2" onClick={handleStartUpload} disabled={ebooks.length === 0 || loading}>
          {loading ? <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" /> : 'Start Upload'}
        </Button>
        <Button variant="danger" className="mr-2" onClick={handleCancelUpload} disabled={!ebooks.some(ebook => ebook.status === 'IN_PROGRESS')}>Cancel Upload</Button>
        <Button variant="danger" onClick={handleRemoveSelected} disabled={selectedEbooks.size === 0 || loading}>
          {loading ? <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" /> : 'Remove Selected'}
        </Button>
        <Button onClick={handleClearDone} className="mb-3">Clear Done</Button>
      </div>
      <Table bordered className="uploading-table" >
        <thead>
          <tr>
            <th>
              <input type="checkbox" onChange={(e) => handleCheckAll(e.target.checked)} checked={ebooks.length > 0 && ebooks.every(ebook => selectedEbooks.has(ebook.id))} />
            </th>
            <th>Task ID</th>
            <th>Status</th>
            <th>Title</th>
            <th>Author</th>
            <th>Price</th>
            <th>Cover Name</th>
            <th>Content Name</th>
            <th>ISBN</th>
            <th>Print Option</th>
            <th>Trim Size</th>
            <th>Bleed</th>
            <th>Paper Back Cover</th>
            <th>AI Content</th>
            <th>Uploaded By</th>
          </tr>
        </thead>
        <tbody>
          {currentEbooks.map((ebook) => (
            <tr key={ebook.id} className={`status-${ebook.status.toLowerCase().replace('_', '-')}`}>
              <td>
                <input type="checkbox" checked={selectedEbooks.has(ebook.id)} onChange={() => handleSelectEbook(ebook.id)} />
              </td>
              <td>{ebook.task_id}</td>
              <td>{ebook.status}</td>
              <td>{ebook.title}</td>
              <td>{ebook.author}</td>
              <td>${ebook.price.toFixed(2)}</td>
              <td>{ebook.cover_name}</td>
              <td>{ebook.content_name}</td>
              <td>{ebook.isbn}</td>
              <td>{ebook.print_option}</td>
              <td>{ebook.trim_size}</td>
              <td>{ebook.bleed ? 'Yes' : 'No'}</td>
              <td>{ebook.paper_back_cover}</td>
              <td>{ebook.ai_content ? 'Yes' : 'No'}</td>
              <td>{ebook.uploaded_by}</td>
            </tr>
          ))}
        </tbody>
      </Table>
      <div className="pagination">
        <Button onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))} disabled={currentPage === 1}>Previous</Button>
        <span>{currentPage} / {totalPages}</span>
        <Button onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))} disabled={currentPage === totalPages}>Next</Button>
        <span>Total: {filteredEbooks.length}</span>
      </div>
    </div>
  );
};

export default UploadEbookTable;