import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import EbooksTab from './components/EbooksTab';
import UsersTab from './components/UsersTab';
import DevicesTab from './components/DevicesTab';
import 'bootstrap/dist/css/bootstrap.min.css';


function App() {
  return (
    <Router>
      <div className="container kdp-container">
        <h1>KDP Website</h1>
        <nav>
          <ul className="nav nav-tabs">
            <li className="nav-item">
              <Link className="nav-link" to="/ebooks">Ebooks</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/users">Users</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/devices">Devices</Link>
            </li>
          </ul>
        </nav>
        <Routes>
          <Route path="/ebooks" element={<EbooksTab/>}/>
          <Route path="/users" element={<UsersTab />} />
          <Route path="/devices" element={<DevicesTab />} />
          <Route path="/" element={<h2>Welcome to the KDP Website</h2>} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
