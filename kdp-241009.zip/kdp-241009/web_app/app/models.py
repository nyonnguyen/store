from pydantic import BaseModel, Field
from typing import Optional, Dict
from main.model.status import Status

# Pydantic model for Ebook
class EbookModel(BaseModel):
    id: Optional[int] = None
    cover_name: str = Field(..., alias='cover_name')
    content_name: str = Field(..., alias='content_name')
    title: str = Field(..., alias='title')
    author_first_name: str = Field(..., alias='author_first_name')
    author_last_name: str = Field(..., alias='author_last_name')
    description: str = Field(..., alias='description')
    category_main: Optional[str] = Field(None, alias='category_main')
    category_sub: Optional[str] = Field(None, alias='category_sub')
    placements: Optional[str] = Field(None, alias='placements')
    keywords: Optional[str] = Field(None, alias='keywords')
    isbn: Optional[str] = Field(None, alias='isbn')
    print_option: Optional[str] = Field(None, alias='print_option')
    trim_size: Optional[str] = Field(None, alias='trim_size')
    bleed: Optional[bool] = Field(False, alias='bleed')
    paper_back_cover: Optional[str] = Field(None, alias='paper_back_cover')
    ai_content: Optional[bool] = Field(False, alias='ai_content')
    price: float = Field(..., alias='price')
    status: Optional[str] = Field(default=Status.NEW.value, alias='status')
    uploaded_by: Optional[str] = None
    task_id: Optional[str] = None
    uploading: Optional[bool] = False

    class Config:
        allow_population_by_field_name = True

    def to_list(self):
        prop_list = []
        for key, value in self.dict().items():
            # ignore id
            if key != 'id':
                prop_list.append(value)
        return prop_list

    def to_tuple(self):
        return tuple(self.to_list())

# Pydantic model for User
class UserModel(BaseModel):
    email: str
    password: str
    key: str

class DeviceModel(BaseModel):
    device_name: str
    port: str

class TaskList(object):
    _instance = None

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(TaskList, cls).__new__(cls)
        return cls._instance

    tasks = {}

    def add_task(self, task_id: str, status: str):
        self.tasks[task_id] = status

    def get_task(self, task_id):
        return self.tasks[task_id]  # O(1) lookup

    def remove_task(self, task_id):
        if task_id in self.tasks:
            del self.tasks[task_id]  # O(1) deletion
            return True
        return False

    def set_task(self, task_id, status):
        if task_id in self.tasks:
            self.tasks[task_id] = status  # O(1) update
            return True
        return False
