import pandas as pd
import json

# Path to your JSON file
json_file = '../data/run_data.json'

# Load JSON data from the file
with open(json_file, 'r') as f:
    json_data = json.load(f)

# Convert JSON data to a DataFrame with updated column names
data_list = []
for item in json_data['data']:
    row = {
        "CoverName": item['cover_name'],
        "ContentName": item['content_name'],
        "Title": item['title'],
        "Author.FirstName": item['author']['first_name'],
        "Author.LastName": item['author']['last_name'],
        "Description": item['description'],
        "Category.Main": item['category']['main'],
        "Category.Sub": item['category']['sub'],
        "Category.Placements": ', '.join(item['category']['placements']),
        "Keywords": ', '.join(item['keywords']),
        "ISBN": item['isbn'],
        "PrintOption": item['print_option'],
        "TrimSize": item['trim_size'],
        "Bleed": item['bleed'],
        "PaperBackCover": item['paper_back_cover'],
        "AIContent": item['ai_content'],
        "Price": item['price']
    }
    data_list.append(row)

# Create DataFrame
df = pd.DataFrame(data_list)

# Save DataFrame to Excel
excel_file = '../data/ebooks.xlsx'
df.to_excel(excel_file, index=False)
print(f"Excel file '{excel_file}' created successfully!")
