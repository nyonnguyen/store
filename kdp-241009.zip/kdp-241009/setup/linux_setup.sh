#!/bin/bash

# Step 1: Check if Python is installed
pythonPath=$(command -v python3 || command -v python)
if [ -z "$pythonPath" ]; then
    echo "Python is not installed. Please download and install Python from https://www.python.org/downloads/"
    exit 1
else
    echo "Python found at: $pythonPath"
fi

# Step 2: Check if npm and Node.js are installed
npmPath=$(command -v npm)
if [ -z "$npmPath" ]; then
    echo "npm and Node.js are not installed. Please download and install them from https://nodejs.org/"
    exit 1
else
    echo "npm found at: $npmPath"
fi

# Step 3: Check if ADB is installed
adbPath=$(command -v adb)
if [ -z "$adbPath" ]; then
    echo "ADB is not installed. Please download and install ADB from https://developer.android.com/studio/releases/platform-tools"
    exit 1
else
    echo "ADB found at: $adbPath"
fi

# Step 4: Install Python virtual environment
python -m venv venv
if [ $? -ne 0 ]; then
    echo "Failed to create a virtual environment. Ensure Python is installed correctly."
    exit 1
fi

# Step 5: Activate the virtual environment
source venv/bin/activate
if [ $? -ne 0 ]; then
    echo "Failed to activate the virtual environment."
    exit 1
fi

# Step 6: Install dependencies from the requirements file
pip install -r requirements.txt
if [ $? -ne 0 ]; then
    echo "Failed to install dependencies. Ensure the requirements file exists and is correct."
    exit 1
fi

# Step 7: Check if Appium is installed
appiumPath=$(command -v appium)
if [ -z "$appiumPath" ]; then
    echo "Appium is not installed. Installing Appium..."
    npm install -g appium
    if [ $? -ne 0 ]; then
        echo "Failed to install Appium. Ensure npm and Node.js are installed correctly."
        exit 1
    fi
else
    echo "Appium found at: $appiumPath"
fi

# Add more steps here
