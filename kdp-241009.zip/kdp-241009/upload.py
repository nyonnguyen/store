import logging
import copy
from main.helpers.device_helper import query_devices
from main.process.appium_process import KdpThread
from main.helpers.config_reader import ConfigReader
from utils.queue_utils import distribute_data_evenly
from main.helpers.db_helper import DBHelper
from web_app.app.models import TaskList


logging.basicConfig(level=logging.INFO, format=f"{__name__} %(asctime)s - %(levelname)s - %(message)s")


def main(device_list, settings, data_list, user_list, task_id):
    threads = []
    try:
        thread_number = min(len(device_list), len(user_list))
        max_upload = settings.get('setting').get('max_upload')
        data_queues = distribute_data_evenly(thread_number, user_list, device_list, data_list, max_upload)

        for i, _queue in enumerate(data_queues):
            device = device_list[i]
            current_settings = copy.deepcopy(settings)
            print("==============================================================")
            print(f"=== SESSION {i}: {device.device_name} ===")
            print(f"Data queue size: {_queue.qsize()}")
            print(f"Data queue: {_queue.queue}\n")

            thread = KdpThread(current_settings, device, _queue, task_id)
            threads.append(thread)
            thread.start()

        for thread in threads:
            thread.join()

        logging.info("All threads done!")

    except KeyboardInterrupt:
        logging.info("Stopping all threads due to keyboard interrupt")
        for thread in threads:
            thread.terminate()  # Add a terminate method in KdpThread
        for thread in threads:
            thread.join()

        logging.info("All threads stopped.")

def start_upload(book_ids, task_id):
    task_list = TaskList()
    try:
        _settings = ConfigReader('configs/settings.json')

        devices = query_devices(True)
        logging.info(devices)

        # Stop the program if no devices are found
        if len(devices) < 1:
            logging.info("No devices found! Exiting the program.")
            task_list.set_task(task_id, "FAILED")
            return False

        db_helper = DBHelper()
        db_helper.create_connection()

        # Get all ebooks match given IDs
        data = db_helper.get_all_ebooks_by_ids(book_ids)
        logging.info(data)
        # Stop the program if no data are found
        if len(data) < 1:
            logging.info("No NEW data to upload! Exiting the program.")
            task_list.set_task(task_id, "FAILED")
            return False

        users = db_helper.get_users()
        logging.info(users)
        # Stop the program if no user are found
        if len(users) < 1:
            logging.info("No users found! Exiting the program.")
            task_list.set_task(task_id, "FAILED")
            return False

        task_list.set_task(task_id, "IN_PROGRESS")

        main(devices, _settings, data, users, task_id)

        # clean_up_previous_run_data()
        db_helper.close_connection()

        task_list.set_task(task_id, "COMPLETED")
        print("COMPLETED UPLOAD!")
        return True
    except Exception as e:
        print(f"Error in task {task_id}: {e}")
        task_list.set_task(task_id, "FAILED")
        print(f"set task status {task_list.get_task(task_id)}")
        return False
