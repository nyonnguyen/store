import logging
import time
from selenium.webdriver.common.by import By
from appium.webdriver.extensions.android.nativekey import AndroidKey
from selenium.webdriver import ActionChains
from selenium.webdriver.common.actions import interaction
from selenium.webdriver.common.actions.action_builder import ActionBuilder
from selenium.webdriver.common.actions.pointer_input import PointerInput
from selenium.webdriver.common.action_chains import ActionChains

DEFAULT_TIMEOUT = 30


class ElementLocator(object):

    # def find_element_by_xpath(self, parent_element, xpath):
    #     return parent_element.find_element(by=AppiumBy.XPATH, value=xpath)
    #
    # def find_element_by_id(self, parent_element, ele_id):
    #     return parent_element.find_element(by=AppiumBy.ID, value=ele_id)

    def __init__(self, driver):
        self.driver = driver

    def wait_for_element(self, by, locator, timeout=DEFAULT_TIMEOUT):
        print(f"Waiting for element: {by} - {locator}")
        self.element(by, locator, timeout=timeout)
        print("Found element!")

    def wait_for_element_enable(self, by, locator, timeout=DEFAULT_TIMEOUT):
        timeout = time.time() + timeout
        while timeout > time.time():
            ele = self.element(by, locator)
            if ele.is_enabled():
                return ele
            time.sleep(1)
        return None

    def wait_for_element_condition(self, by, locator, condition, timeout=DEFAULT_TIMEOUT):
        print(f"Waiting for element: {by} - {locator} ...")
        timeout = time.time() + timeout
        while timeout > time.time():
            ele = self.element(by, locator)
            if condition(ele):
                print("Found element!")
                return ele
            time.sleep(1)
        print(f"Wait for element {by} - {locator} - timeout: {timeout}")
        return None

    def wait_for_page_url_contain(self, url_content, timeout=DEFAULT_TIMEOUT):
        timeout = time.time() + timeout
        while timeout > time.time():
            if url_content in self.driver.current_url:
                return
            time.sleep(1)
        raise Exception(f"Page not loaded with URL: {url_content}")

    def element(self, by, locator, timeout=DEFAULT_TIMEOUT):
        logging.debug(f"Finding element: {by} - {locator}")
        timeout = time.time() + timeout
        while timeout > time.time():
            try:
                return self.driver.find_element(by=by, value=locator)
            except:
                print(f"Not found element with {by} ['{locator}']")
            time.sleep(1)  # Delay 1s before retry
        return None

    def elements(self, by, locator, timeout=DEFAULT_TIMEOUT):
        logging.debug(f"Finding element list: {by} - {locator}")
        timeout = time.time() + timeout
        while timeout > time.time():
            try:
                return self.driver.find_elements(by=by, value=locator)
            except:
                print(f"Not found element with {by} ['{locator}']")
            time.sleep(1)  # Delay 1s before retry
        return None

    def element_id(self, el_id, timeout=DEFAULT_TIMEOUT):
        logging.debug(f"Finding element: {el_id}")
        timeout = time.time() + timeout
        while timeout > time.time():
            try:
                return self.driver.find_element(by=By.ID, value=el_id)
            except:
                print(f"Not found element with ID ['{el_id}']")
            time.sleep(1)  # Delay 1s before retry
        return None

    def dismiss_keyboard(self):
        self.driver.hide_keyboard()
        print("Hide keyboard")

    def tap(self, by, locator, timeout=3):
        self.element(by, locator, timeout=timeout).click()
        print(f"Tap on element {by} '{locator}'")

    def tap_id(self, ele_id):
        self.element_id(ele_id).click()

    def js_tap(self, by, locator):
        self.wait_for_element_enable(by, locator)
        if by == By.CSS_SELECTOR:
            self.driver.execute_script(f"document.querySelector('{locator}').click()")
        elif by == By.XPATH:
            self.driver.execute_script(
                f"document.evaluate(\'{locator}\', document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.click();")
        else:
            el = self.element(by, locator)
            self.driver.execute_script("arguments[0].click();", el)
        print(f"JS Tap on element {by} '{locator}'")

    def js_set_value(self, by, locator, value):
        self.wait_for_element_enable(by, locator)
        if by == By.CSS_SELECTOR:
            self.driver.execute_script(f"document.querySelector('{locator}').value = '{value}'")
        elif by == By.XPATH:
            self.driver.execute_script(
                f"document.evaluate(\'{locator}\', document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.value = '{value}';")
        else:
            el = self.element(by, locator)
            self.driver.execute_script("arguments[0].value = arguments[1];", el, value)
        print(f"JS Set value '{value}' on element {by} '{locator}'")

    def input_text(self, by, locator, input_str):
        el = self.element(by, locator)
        self.input_text_element(el, input_str)
        print(f"Enter '{input_str}' into field {by} '{locator}'")

    def input_text_id(self, _id, input_str):
        el = self.element_id(_id)
        self.input_text_element(el, input_str)
        print(f"Enter '{input_str}' into field id {_id}")

    def input_text_element(self, element, input_str):
        element.click()
        time.sleep(0.2)
        element.send_keys(input_str)
        self.dismiss_keyboard()
        time.sleep(0.5)

    def get_text_by_id(self, id):
        return self.element_id(id).get_attribute('text')

    def input_text_by_keyboard(self, input_str):
        input_keycodes = self._string_to_keycodes(input_str)
        for k in input_keycodes:
            self.driver.press_keycode(keycode=k)

    def press_search(self):
        self.driver.press_keycode(keycode=AndroidKey.SEARCH)

    def press_enter(self):
        self.driver.press_keycode(keycode=AndroidKey.ENTER)

    def action_tap(self, by, locator):
        el = self.element(by, locator)
        center_x = el.location.get('x') + el.size['width'] / 2
        center_y = el.location.get('y') + el.size['height'] / 2

        actions = ActionChains(self.driver)
        # override as 'touch' pointer action
        actions.w3c_actions = ActionBuilder(self.driver, mouse=PointerInput(interaction.POINTER_MOUSE, "mouse"))
        actions.w3c_actions.pointer_action.move_to_location(center_x, center_y)
        actions.w3c_actions.pointer_action.pointer_down()
        actions.w3c_actions.pointer_action.pause(2)
        actions.w3c_actions.pointer_action.move_to_location(center_x, center_y)
        actions.w3c_actions.pointer_action.release()
        actions.perform()


    @staticmethod
    def _string_to_keycodes(input_str):
        keycodes = []
        for char in input_str:
            keycode = None
            if char.isalpha():
                if char.isupper():
                    # Switch on Shift key
                    keycodes.append(AndroidKey.SHIFT_LEFT)
                    keycodes.append(AndroidKey.SHIFT_LEFT)
                # Convert the character to uppercase and get its AndroidKey constant
                keycode = getattr(AndroidKey, char.upper(), None)
            if char.isnumeric():
                keycode = getattr(AndroidKey, f"NUMPAD_{char}", None)
            if char == ' ':
                keycode = AndroidKey.SPACE
            if keycode is not None:
                keycodes.append(keycode)
            else:
                print(f"Keycode for character '{char}' not found.")
            # Switch off Shift key
            if char.isupper():
                keycodes.append(AndroidKey.SHIFT_LEFT)
        return keycodes