import sqlite3
from threading import Lock
from sqlite3 import Error
import logging
import pandas as pd

from main.model.kdp import Ebook, User
from main.model.status import Status
from utils.files_utils import get_path
from web_app.app.models import EbookModel


class DBHelper:
    def __init__(self, db_file=get_path('db/kdp.db')):
        """Initialize with the path to the SQLite database file."""
        self.db_file = db_file
        self.conn = None

    def create_connection(self):
        """Create a database connection to the SQLite database."""
        try:
            self.conn = sqlite3.connect(self.db_file, check_same_thread=False)
            self.conn.row_factory = sqlite3.Row
            print(f"Connection to SQLite DB '{self.db_file}' successful")
        except Error as e:
            print(f"Error creating connection: {e}")
        return self.conn

    def close_connection(self):
        """Close the database connection."""
        if self.conn:
            self.conn.close()
            print("Connection closed.")

    def create_ebook_table(self):
        """Create the ebooks table."""
        create_table_sql = """
        CREATE TABLE IF NOT EXISTS ebooks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            CoverName TEXT NOT NULL,
            ContentName TEXT NOT NULL,
            Title TEXT NOT NULL,
            AuthorFirstName TEXT,
            AuthorLastName TEXT,
            Description TEXT,
            CategoryMain TEXT,
            CategorySub TEXT,
            CategoryPlacements TEXT,
            Keywords TEXT,
            ISBN TEXT,
            PrintOption TEXT,
            TrimSize TEXT,
            Bleed BOOLEAN,
            PaperBackCover TEXT,
            AIContent BOOLEAN,
            Price REAL,
            Status TEXT DEFAULT NULL,
            UploadedBy TEXT DEFAULT NULL,
            TaskId TEXT DEFAULT NULL
            Uploading BOOLEAN DEFAULT FALSE
        );
        """
        try:
            self.conn.execute(create_table_sql)
            print("Table 'ebooks' created successfully.")
        except Error as e:
            print(f"Error creating table: {e}")

    def create_users_table(self):
        """Create the users table."""
        create_table_sql = """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            key TEXT NOT NULL
        );
        """
        try:
            self.conn.execute(create_table_sql)
            print("Table 'users' created successfully.")
        except Error as e:
            print(f"Error creating table: {e}")

    def insert_ebook(self, ebook: EbookModel):
        sql = """
        INSERT INTO ebooks (CoverName, ContentName, Title, AuthorFirstName, AuthorLastName, Description, 
                            CategoryMain, CategorySub, CategoryPlacements, Keywords, ISBN, PrintOption, 
                            TrimSize, Bleed, PaperBackCover, AIContent, Price, Status, UploadedBy, TaskId, Uploading)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        try:
            cursor = self.conn.cursor()
            print(ebook.to_tuple())
            cursor.execute(sql, ebook.to_tuple())
            self.conn.commit()
            ebook_id = cursor.lastrowid  # Correct usage
            print("Ebook inserted successfully.")
            return ebook_id
        except Error as e:
            print(f"Error inserting ebook: {e}")
            return None

    def insert_user(self, user_data):
        """Insert a new user record into the users table."""
        sql = """
        INSERT INTO users (email, password, key)
        VALUES (?, ?, ?);
        """
        try:
            self.conn.execute(sql, user_data)
            self.conn.commit()
            print("User inserted successfully.")
        except Error as e:
            print(f"Error inserting user: {e}")

    def insert_or_update_user(self, user_data):
        """
        Insert a new user record into the users table if the email doesn't exist,
        otherwise update the existing record.
        """

        # SQL query to check if the email exists
        check_sql = "SELECT COUNT(1) FROM users WHERE email = ?"

        # SQL query to insert a new user
        insert_sql = """
        INSERT INTO users (email, password, key)
        VALUES (?, ?, ?);
        """

        # SQL query to update an existing user
        update_sql = """
        UPDATE users
        SET password = ?, key = ?
        WHERE email = ?;
        """

        try:
            cursor = self.conn.cursor()

            # Check if the email already exists
            cursor.execute(check_sql, (user_data.iloc[0],))  # user_data[0] is the email
            result = cursor.fetchone()

            if result[0] == 0:  # Email does not exist, insert a new record
                cursor.execute(insert_sql, user_data)
                self.conn.commit()
                print(f"User {user_data.iloc[0]} inserted successfully.")
            else:  # Email exists, update the existing record
                cursor.execute(update_sql, (user_data.iloc[1], user_data.iloc[2], user_data.iloc[0]))
                self.conn.commit()
                print(f"User {user_data.iloc[0]} updated successfully.")

        except Exception as e:
            print(f"Error inserting or updating user: {e}")

    def update_status(self, ebook_id, status: Status, uploaded_by, task_id):
        print(f"Updating Status to '{status}' for book ID '{ebook_id}' - TaskId {task_id}.")
        sql = "UPDATE ebooks SET Status = ?, UploadedBy = ?, TaskId = ? WHERE id = ?"
        try:
            self.conn.execute(sql, (status, uploaded_by, task_id, ebook_id))
            self.conn.commit()
            print(f"Status updated to '{status}' for book ID '{ebook_id}' - TaskId {task_id}.")
        except Error as e:
            print(f"Error updating status: {e}")

    def set_book_uploading(self, ebook_id, uploading):
        print(f"Setting uploading to '{uploading}' for book ID '{ebook_id}'.")
        sql = "UPDATE ebooks SET Uploading = ? WHERE id = ?"
        try:
            self.conn.execute(sql, (uploading, ebook_id))
            self.conn.commit()
            print(f"Uploading set to '{uploading}' for book ID '{ebook_id}'.")
        except Error as e:
            print(f"Error setting uploading: {e}")

    def update_book(self, ebook_id, ebook_data):
        """Update an existing ebook record in the ebooks table."""
        sql = """
        UPDATE ebooks
        SET CoverName = ?, ContentName = ?, Title = ?, AuthorFirstName = ?, AuthorLastName = ?,
            Description = ?, CategoryMain = ?, CategorySub = ?, CategoryPlacements = ?, Keywords = ?,
            ISBN = ?, PrintOption = ?, TrimSize = ?, Bleed = ?, PaperBackCover = ?, AIContent = ?,
            Price = ?, Status = ?, UploadedBy = ?, TaskId = ?, Uploading = ?
        WHERE id = ?;
        """
        try:
            self.conn.execute(sql, (*ebook_data.to_tuple(), ebook_id))
            self.conn.commit()
            print(f"Ebook {ebook_id} updated successfully.")
            return True
        except Error as e:
            print(f"Error updating ebook: {e}")
            return False

    def delete_book(self, ebook_ids):
        """Delete an ebook record from the ebooks table."""
        if len(ebook_ids) == 1:
            sql = "DELETE FROM ebooks WHERE id = ?"
            params = (ebook_ids[0],)
        else:
            sql = f"DELETE FROM ebooks WHERE id IN ({','.join(['?'] * len(ebook_ids))})"
            params = ebook_ids
        try:
            self.conn.execute(sql, params)
            self.conn.commit()
            print(f"{len(ebook_ids)} Ebooks deleted successfully.")
            return True
        except Error as e:
            print(f"Error deleting ebook: {e}")
            return False

    def get_unprocessed_ebooks(self):
        """Retrieve all ebooks where the status is NULL (not processed yet)."""
        sql = "SELECT * FROM ebooks WHERE Status IS NULL"
        try:
            cursor = self.conn.cursor()
            cursor.execute(sql)
            rows = cursor.fetchall()
            return rows
        except Error as e:
            print(f"Error retrieving unprocessed ebooks: {e}")
            return []

    def get_all_ebooks(self, status=None):
        """
        Fetch all ebooks data from the database and return them as Ebook objects.
        If a status is provided, only return ebooks with that status.
        """
        cursor = self.conn.cursor()

        # Query depending on whether a status is specified
        # In case, need to query all data has given status and null:
        # SELECT * FROM ebooks WHERE Status = ? OR Status IS NULL
        if status:
            cursor.execute("SELECT * FROM ebooks WHERE Status = ?", (status,))
        else:
            cursor.execute("SELECT * FROM ebooks")

        rows = cursor.fetchall()
        return self._rows_to_books(rows)

    def get_all_ebooks_by_ids(self, list_ids=None):
        """
        Fetch all ebooks data from the database and return them as Ebook objects.
        :param list_ids:
        :return: list of Book
        """
        logging.info(f"get_all_ebooks_by_ids: {list_ids}")
        cursor = self.conn.cursor()
        if len(list_ids) > 1:
            list_ids = ','.join([str(_id) for _id in list_ids])
        else:
            list_ids = list_ids[0]
        query = f"SELECT * FROM ebooks WHERE id IN ({list_ids})"
        logging.info(f"execute query {query}")
        cursor.execute(query)

        rows = cursor.fetchall()
        return self._rows_to_books(rows)

    @staticmethod
    def _rows_to_books(rows):
        ebooks = []
        for row in rows:
            ebook = Ebook(
                _id=row['id'],
                cover_name=row['CoverName'],
                content_name=row['ContentName'],
                title=row['Title'],
                author_first_name=row['AuthorFirstName'],
                author_last_name=row['AuthorLastName'],
                description=row['Description'],
                category_main=row['CategoryMain'],
                category_sub=row['CategorySub'],
                placements=row['CategoryPlacements'],
                keywords=row['Keywords'],
                isbn=row['ISBN'],
                print_option=row['PrintOption'],
                trim_size=row['TrimSize'],
                bleed=row['Bleed'],
                paper_back_cover=row['PaperBackCover'],
                ai_content=row['AIContent'],
                price=row['Price'],
                status=row['Status'],  # Handling the new status field
                uploaded_by=row['UploadedBy'],
                task_id=row['TaskId'],
                uploading=row['Uploading']
            )
            ebooks.append(ebook)

        return ebooks

    def get_users(self):
        """Fetch all users data from the users table and return them as User objects."""
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM users")
        rows = cursor.fetchall()

        users = []
        for row in rows:
            user = User(
                email=row['email'],
                password=row['password'],
                key=row['key']
            )
            users.append(user)

        return users

    def check_table_exists(self, table_name):
        """Check if a table exists in the database."""
        cursor = self.conn.cursor()
        cursor.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{table_name}'")
        table_exists = cursor.fetchone()
        return table_exists is not None