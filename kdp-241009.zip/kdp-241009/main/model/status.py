from enum import Enum

class Status(Enum):
    NEW = "NEW"
    IN_PROGRESS = "IN_PROGRESS"
    FAILED = "FAILED"
    DONE = "DONE"
    SKIPPED = "SKIPPED"
    READY_UPLOAD = "READY_UPLOAD"