class Ebook:
    def __init__(self, _id, cover_name, content_name, title, author_first_name, author_last_name, description,
                 category_main, category_sub, placements, keywords, isbn, print_option, trim_size, bleed,
                 paper_back_cover, ai_content, price, status, uploaded_by, task_id, uploading):
        self.id = _id
        self.cover_name = cover_name
        self.content_name = content_name
        self.title = title
        self.author_first_name = author_first_name
        self.author_last_name = author_last_name
        self.description = description
        self.category_main = category_main
        self.category_sub = category_sub
        self.placements = placements
        self.keywords = keywords
        self.isbn = isbn
        self.print_option = print_option
        self.trim_size = trim_size
        self.bleed = bleed
        self.paper_back_cover = paper_back_cover
        self.ai_content = ai_content
        self.price = price
        self.status = status  # New field for tracking status
        self.uploaded_by = uploaded_by
        self.task_id = task_id
        self.uploading = uploading

    def to_dict(self):
        """Convert Ebook instance to a dictionary."""
        return {
            "id": self.id,
            "cover_name": self.cover_name,
            "content_name": self.content_name,
            "title": self.title,
            "author_first_name": self.author_first_name,
            "author_last_name": self.author_last_name,
            "description": self.description,
            "category_main": self.category_main,
            "category_sub": self.category_sub,
            "placements": self.placements,
            "keywords": self.keywords,
            "isbn": self.isbn,
            "print_option": self.print_option,
            "trim_size": self.trim_size,
            "bleed": self.bleed,
            "paper_back_cover": self.paper_back_cover,
            "ai_content": self.ai_content,
            "price": self.price,
            "status": self.status,
            "uploaded_by": self.uploaded_by,
            "task_id": self.task_id,
            "uploading": self.uploading
        }

    def __repr__(self):
        return f"Ebook(id={self.id}, title={self.title}, status={self.status}, author={self.author_first_name} {self.author_last_name}, price={self.price})"


class User:
    def __init__(self, email, password, key):
        self.email = email
        self.password = password
        self.key = key

    def to_dict(self):
        """Convert User instance to a dictionary."""
        return {
            "email": self.email,
            "password": self.password,
            "key": self.key
        }

    def __repr__(self):
        return f"User(email={self.email})"
