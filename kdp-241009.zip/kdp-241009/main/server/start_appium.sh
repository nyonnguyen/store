#!/bin/bash

#source ~/.mobile
DEV_TOOLS="/home/jenkins/DevTools"
JAVA_HOME="c:/Program Files/Common Files/Oracle/Java/javapath"
ANDROID_HOME="C:/Users/NyonAx/AppData/Local/Android/Sdk"
export JAVA_HOME
export ANDROID_HOME
PATH="$JAVA_HOME/bin:$ANDROID_HOME/cmdline-tools/tools/bin:$ANDROID_HOME/platform-tools:$PATH"

latest="4.24.0"

selenium_hub="java -jar selenium-server-${latest}.jar hub"
appium_server="appium --config appium1.yml"
appium_node="java -jar selenium-server-${latest}.jar node --config appium1.toml"
appium_server2="appium --config appium2.yml"
appium_node2="java -jar selenium-server-${latest}.jar node --config appium2.toml"

log_selenium_grid="selenium_grid.log"
log_appium_server="appium_server.log"
log_appium_node="appium_node.log"
log_appium_server2="appium_server2.log"
log_appium_node2="appium_node2.log"


terminate_background_processes() {
    echo "Terminating background processes..."
    kill $(jobs -p)
    exit 0
}

trap terminate_background_processes EXIT

echo "Start Selenium Grid: $selenium_hub"
$selenium_hub > >(tee -a $log_selenium_grid) 2>&1 &
echo "Selenium Grid output written to $log_selenium_grid"

echo "Start appium server: $appium_server"
$appium_server > >(tee -a $log_appium_server) 2>&1 &
echo "Appium server output written to $log_appium_server"

echo "Start appium node: $appium_node"
$appium_node > >(tee -a $log_appium_node) 2>&1 &
echo "Appium node output written to $log_appium_node"

echo "Start appium server: $appium_server2"
$appium_server2 > >(tee -a $log_appium_server2) 2>&1 &
echo "Appium server output written to $log_appium_server2"

echo "Start appium node: $appium_node2"
$appium_node2 > >(tee -a $log_appium_node2) 2>&1 &
echo "Appium node output written to $log_appium_node2"

echo "Commands running in background. Press Ctrl+C to terminate script."
wait
