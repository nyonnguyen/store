import time

from appium.webdriver.common.appiumby import AppiumBy
from main.helpers.element_helper import ElementLocator
from utils.otp_utils import generate_otp


class LoginPage(ElementLocator):

    MAIN_URL = "https://kdp.amazon.com/en_US/bookshelf"
    LOGOUT_URL = "https://kdp.amazon.com/en_US/signout"
    # URL contain signin
    login_label = (AppiumBy.XPATH, '//label[@text()="Email or mobile phone number"]')
    email_input = (AppiumBy.XPATH, '//*[@id="ap_email"]')
    email_login_input = (AppiumBy.XPATH, '//*[@id="ap_email_login"]')
    continue_button = (AppiumBy.XPATH, '//*[@id="ap_login_form"]//*[@id="continue"]')
    password_input = (AppiumBy.XPATH, '//*[@id="ap_password"]')
    signin_button = (AppiumBy.XPATH, '//*[@id="signInSubmit"]')
    otp_input = (AppiumBy.XPATH, '//*[@id="auth-mfa-otpcode"]')
    auth_signin_button = (AppiumBy.XPATH, '//*[@id="auth-signin-button"]')

    signout_button = (AppiumBy.XPATH, '//a[text()="Sign out"]')

    def __init__(self, driver):
        self.driver = driver

    def navigate(self):
        print(f"Navigating to {self.MAIN_URL}")
        self.driver.get(self.MAIN_URL)
        self.is_loaded()

    def is_loaded(self):
        self.wait_for_element(*self.email_input)

    def enter_email(self, email):
        self.input_text(*self.email_input, email)

    def enter_email_login(self, email):
        """
        An alternate input filed for email login. This field appears randomly by KDP
        """
        self.input_text(*self.email_login_input, email)

    def enter_password(self, password):
        self.input_text(*self.password_input, password)

    def is_password_input(self, timeout=3) -> bool:
        return self.element(*self.password_input, timeout=timeout).is_displayed()

    def enter_otp(self, otp):
        self.input_text(*self.otp_input, otp)

    def tap_continue(self):
        self.tap(*self.continue_button)

    def tap_signin(self):
        self.tap(*self.signin_button)

    def tap_auth_signin(self):
        self.tap(*self.auth_signin_button)

    def login(self, email, password, scr_key, retries=3, delay=2) -> bool:
        """
        Attempt to login with retries in case of flakiness during the email entry step.

        Args:
        - email (str): The email address to log in.
        - password (str): The password to log in.
        - scr_key (str): The secret key for OTP generation.
        - retries (int): Number of times to retry on failure.
        - delay (int): Delay in seconds between retries.

        Returns:
        - bool: True if login is successful, False otherwise.
        """
        for attempt in range(retries):
            try:
                self.navigate()

                # KDP randomly asks for password at the first screen or the second screen
                if self.is_password_input():
                    self.enter_email(email)
                    self.enter_password(password)
                else:
                    self.enter_email_login(email)
                    self.tap_continue()
                    self.enter_password(password)
                break

            except Exception as e:
                print(f"Attempt {attempt + 1}/{retries} failed: {e}")
                if attempt < retries - 1:
                    time.sleep(delay)  # Wait before retrying
                else:
                    print("Max retries reached. Login failed.")
                    return False
        self.tap_signin()
        self.enter_otp(generate_otp(scr_key))
        self.tap_auth_signin()

