import time
from selenium.webdriver.common.by import By

from main.model.status import Status
from main.pages.kdp_locators import KdpLocators


class KdpPage(KdpLocators):


    def __init__(self, driver, data):
        super().__init__(driver)
        self.driver = driver
        self.data = data

    def is_loaded(self):
        self.wait_for_element(*self.create_paper)

    def navigate(self):
        print(f"Navigating to {self.CREATE_URL}")
        self.driver.get(self.CREATE_URL)
        self.is_loaded()

    def click_create_paper(self):
        self.tap(*self.create_paper)

    def enter_book_title(self):
        self.input_text(*self.book_title_input, self.data.title)

    def enter_first_name(self):
        self.input_text(*self.author_first_name_input, self.data.author_first_name)

    def enter_last_name(self):
        self.input_text(*self.author_last_name_input, self.data.author_last_name)

    def enter_description(self):
        # This is workaround for input text with JS
        # The text won't display by using this way, but the value is set in submit form
        self.js_set_value(*self.description_input, self.data.description)

    def select_i_owns(self):
        self.js_tap(*self.publish_i_owns)

    def select_sexual_content_no(self):
        self.js_tap(*self.audience_sexual_content_no)

    def tap_category_button(self):
        self.js_tap(*self.choose_category_button)
        self.wait_for_element(*self.ctg_diag_category_button)

    # ----- Category Diag -----

    def set_category(self):
        # Tap Category button
        time.sleep(2)
        self.wait_for_element(*self.ctg_diag_category_button)
        self.driver.execute_script(f"document.querySelectorAll('{self.ctg_diag_category_button_css}')[0].click()")
        self.wait_for_element(*self.active_popup_list)
        # Select Category value
        self.select_popup_value(self.data.category_main)

        # Tap Subcategory button
        if self.data.category_main != '':
            self.wait_for_element(*self.ctg_diag_subcategory_button)
            self.driver.execute_script(f"document.querySelectorAll('{self.ctg_diag_category_button_css}')[1].click()")
            self.wait_for_element(*self.active_popup_list)
            # Select Subcategory value
            self.select_popup_value(self.data.category_sub)
        time.sleep(3)   # Wait for placements to load
        self.set_ctg_diag_placement()
        self.tap_ctg_diag_save_button()
        time.sleep(2)

    def tap_ctg_diag_category_button(self):
        self.js_tap(*self.ctg_diag_category_button)
        self.wait_for_element(*self.active_popup_list)

    def select_popup_value(self, value):
        self.input_text_by_keyboard(value)
        self.press_enter()

    def set_ctg_diag_category(self):
        self.select_popup_value(self.data.category_main)

    def tap_ctg_diag_subcategory_button(self):
        self.js_tap(*self.ctg_diag_subcategory_button)
        self.wait_for_element(*self.active_popup_list)

    def set_ctg_diag_subcategory(self):
        self.select_popup_value(self.data.category_sub)

    def set_ctg_diag_placement(self):
        for i in self.data.category_placements:
            self.js_tap(By.XPATH, self.CTG_DIAG_PLACEMENT_XPATH % i)

    def tap_ctg_diag_save_button(self):
        self.js_tap(*self.ctg_diag_save_button)

    def enter_keywords(self):
        if self.data.keywords:
            for i, keyword in enumerate(self.data.keywords):
                self.input_text(*getattr(self, f'keywords_input{i+1}_input'), keyword)

    def select_public_and_release(self):
        self.js_tap(*self.public_and_release_radio)

    def select_release_now(self):
        self.js_tap(*self.release_now_radio)

    # ----- Content Tab -----

    def select_free_isbn_radio(self):
        self.js_tap(*self.isbn_free_radio)

    def select_own_isbn_radio(self):
        self.js_tap(*self.isbn_own_radio)

    def tap_isbn_assign_button(self):
        self.js_tap(*self.isbn_assign_button)

    def tap_isbn_assign_confirm_button(self):
        self.js_tap(*self.isbn_assign_confirm_button)
        self.wait_for_element_enable(*self.isbn_success_message)

    def select_paper_type(self):
        paper_type = self.data.print_option
        self.js_tap(By.XPATH, self.PAPER_TYPE_XPATH % paper_type)

    def select_trim_size(self):
        if self.data.trim_size != '':
            self.js_tap(*self.trim_size_custom_buton)
            time.sleep(2)
            self.js_tap(By.XPATH, self.TRIM_SIZE_SELECT_XPATH % self.data.trim_size)
        else:
            self.js_tap(*self.trim_size_default_buton)

    def select_bleed_setting(self):
        if self.data.bleed:
            self.js_tap(*self.bleed_setting_button)
        else:
            self.js_tap(*self.no_bleed_setting_button)

    def select_paper_back(self):
        if self.data.paper_back_cover == 'matte':
            self.js_tap(*self.paper_back_matte_button)
        else:
            self.js_tap(*self.paper_back_glossy_button)

    def wait_for_popover_appear(self, by, locator, timeout=30):
        def condition(ele):
            client_h = ele.get_property("clientHeight")
            print(f"Condition: clientHeight is {client_h}")
            return client_h != 0

        return self.wait_for_element_condition(by, locator, condition, timeout)

    def wait_for_popover_gone(self, by, locator, timeout=30):
        def condition(ele):
            client_h = ele.get_property("clientHeight")
            print(f"Condition: clientHeight is {client_h}")
            return client_h == 0

        return self.wait_for_element_condition(by, locator, condition, timeout)

    def upload_manuscript(self):
        self.tap(*self.upload_manuscript_button)
        # a browser diag open to browse file. select file and upload
        try:
            alert = self.driver.switch_to.context('NATIVE_APP').alert
            alert.driver.find_element(By.ID, "com.android.packageinstaller:id/permission_allow_button").click()
        except:
            pass
        try:
            self.tap(By.XPATH, "//*[@text='Files']")
        except:
            pass
        self.tap(By.XPATH, '//android.widget.ImageButton[@content-desc="Show roots"]')
        self.tap(By.XPATH, '//android.widget.ListView//android.widget.LinearLayout/android.widget.TextView[@text="Downloads"]')
        content = self.data['content_name']
        self.tap(By.XPATH, f'//android.widget.TextView[@text="{content}"]')
        self.driver.switch_to.context('CHROMIUM')
        # wait for success message
        time.sleep(3)
        self.wait_for_popover_appear(*self.uploading_popover)
        self.wait_for_popover_gone(*self.uploading_popover, timeout=120)
        self.wait_for_popover_appear(*self.uploaded_success_span)


    def upload_cover(self):
        self.js_tap(*self.upload_cover_radio)
        self.tap(*self.upload_cover_button)
        # a browser diag open to browse file. select file and upload
        self.driver.switch_to.context('NATIVE_APP')
        try:
            self.tap(By.XPATH, "//*[@text='Files']")
        except:
            pass
        self.tap(By.XPATH, '//android.widget.ImageButton[@content-desc="Show roots"]')
        self.tap(By.XPATH, '//android.widget.ListView//android.widget.LinearLayout/android.widget.TextView[@text="Downloads"]')
        cover = self.data['cover_name']
        self.tap(By.XPATH, f'//android.widget.TextView[@text="{cover}"]')
        self.driver.switch_to.context('CHROMIUM')
        # wait for success message
        time.sleep(3)
        self.wait_for_popover_appear(*self.uploading_popover)
        self.wait_for_popover_gone(*self.uploading_popover, timeout=120)
        self.wait_for_popover_appear(*self.upload_cover_success_span)

    def set_ai_generate_content(self):
        if self.data.ai_content:
            self.js_tap(*self.gen_ai_content_yes_radio)
        else:
            self.js_tap(*self.gen_ai_content_no_radio)

    # Preview

    def launch_preview(self):
        self.js_tap(*self.launch_preview_button)
        try:
            self.js_tap(*self.preview_continue_button)
        except:
            pass
        self.wait_for_element(*self.approval_enabled_button, timeout=60)

    def tap_approval_enabled_button(self):
        self.js_tap(*self.approval_enabled_button)

    def select_all_territories(self):
        self.js_tap(*self.all_territories)

    # ----- Pricing Tab -----

    def enter_us_price(self):
        self.input_text(*self.us_price_input, self.data.price)

    def save_as_draft(self):
        self.js_tap(*self.save_as_draft_button)
        time.sleep(3)
        self.wait_for_element_enable(*self.save_success_message)
        print(f"Saved as draft: {self.data.title}")

    def save_continue(self):
        self.js_tap(*self.save_continue_button)

    def wait_for_saving(self):
        self.wait_for_popover_appear(*self.saving_popover, timeout=3)
        self.wait_for_popover_gone(*self.saving_popover, timeout=120)
        print(f"Saved and continue: {self.data.title}")

    def save_publish(self):
        self.js_tap(*self.save_publish_button)

    def publish(self) -> Status:
        try:
            print(f"Publishing {self.data.title}")
            # ===== Details Tab =====
            print(f"Filling details for {self.data.title}")
            self.click_create_paper()
            self.enter_book_title()
            # self.enter_first_name()
            # self.enter_last_name()
            # self.enter_description()
            # self.select_i_owns()
            # self.select_sexual_content_no()
            # time.sleep(3)   # category loading
            # self.tap_category_button()
            # self.set_category()
            # self.enter_keywords()
            # self.select_public_and_release()
            # self.select_release_now()
            #
            # self.save_continue()
            # self.wait_for_page_url_contain("content")   # Page content is navigated
            #
            # # ===== Content Tab =====
            # print(f"Filling content for {self.data.title}")
            #
            # if self.data['isbn'] == '':
            #     self.select_free_isbn_radio()
            #     self.tap_isbn_assign_button()
            #     time.sleep(3)
            #     self.tap_isbn_assign_confirm_button()  # TOD: fix here
            # else:
            #     self.select_own_isbn_radio()
            #     # TODO: add ISBN input
            #
            # self.select_paper_type()
            # self.select_trim_size()
            # self.select_bleed_setting()
            # self.select_paper_back()
            # time.sleep(5)
            # self.upload_manuscript()   # wait for uploading success
            # self.upload_cover()     # Wait for uploading success
            #
            # # Preview book
            # self.launch_preview()
            # self.tap_approval_enabled_button()  # wait for back to main page
            #
            # # generate AI
            # self.set_ai_generate_content()
            #
            # self.wait_for_element(*self.save_continue_button)
            # self.save_continue()
            # self.wait_for_page_url_contain("pricing")
            #
            # # ===== Pricing Tab =====
            #
            # print(f"Filling pricing for {self.data.title}")
            # self.select_all_territories()
            # self.enter_us_price()
            #
            # # Save as draft
            # self.save_as_draft()

            # Save and publish
            # self.save_continue()
        except Exception as e:
            print(f"Failed to publish: {e}")
            return Status.FAILED

        # TODO: Handle upload status to return value
        print("Upload successfully!")
        return Status.DONE