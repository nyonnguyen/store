import os
import shutil

from fastapi import UploadFile

def get_project_root():
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def get_path(file):
    project_root = get_project_root()
    return f"{project_root}/{file}"


UPLOAD_DIR = "data/uploads"

def save_uploaded_file(file: UploadFile) -> str:
    # Ensure the upload directory exists
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    save_file_path = f"{UPLOAD_DIR}/{file.filename}"
    file_path = get_path(save_file_path)
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    return file_path

def remove_file(file_path):
    if os.path.exists(file_path):
        os.remove(file_path)