import psutil

def kill_appium_processes():
    # process_names = ['node', 'appium']
    process_names = ['node', 'appium']
    # Iterate over all running processes
    for proc in psutil.process_iter(['pid', 'name']):
        try:
            # Check if the process name is in the list of names to kill
            if any(proc_name in proc.info['name'].lower() for proc_name in process_names):
                # Terminate the process
                proc.kill()
                print(f"Killed process {proc.info['name']} (PID: {proc.info['pid']})")
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
