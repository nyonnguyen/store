import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Modal, Button, Form } from 'react-bootstrap';
import './EbooksTab.css';

const EbooksTab = () => {
  const [ebooks, setEbooks] = useState([]);
  const [formData, setFormData] = useState({
    title: '',
    author_first_name: '',
    author_last_name: '',
    price: 0,
    status: '',
    cover_name: '',
    content_name: '',
    description: '',
    category_main: '',
    category_sub: '',
    placements: '',
    keywords: '',
    isbn: '',
    print_option: '',
    trim_size: '',
    bleed: '',
    paper_back_cover: '',
    ai_content: '',
  });
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState(null);

  const fetchEbooks = () => {
    axios.get('/ebooks/')
      .then(res => setEbooks(res.data))
      .catch(err => console.error(err));
  };

  useEffect(() => {
    fetchEbooks();
    const interval = setInterval(fetchEbooks, 30000); // Auto refresh every 30 seconds
    return () => clearInterval(interval);
  }, []);

  const handleDelete = (id) => {
    if (window.confirm('Are you sure you want to delete this eBook?')) {
      axios.delete(`/ebooks/${id}`)
        .then(fetchEbooks)
        .catch(err => console.error(err));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('/ebooks/', formData)
      .then(() => {
        fetchEbooks();
        setShowAddModal(false); // Close modal after adding
      })
      .catch(err => console.error(err));
  };

  const handleBulkUpload = () => {
    const formData = new FormData();
    formData.append('file', selectedFiles);

    axios.post('/ebooks/bulk-upload', formData)
      .then(() => {
        fetchEbooks();
        setSelectedFiles(null); // Clear selected file after upload
      })
      .catch(err => console.error(err));
  };

  const handleFileChange = (e) => {
    setSelectedFiles(e.target.files[0]);
  };

  return (
    <div className="container mt-4">
      <h3>eBooks List</h3>
      <div className="d-flex mb-3">
        <button className="btn btn-primary mr-2" onClick={fetchEbooks}>Refresh</button>
        <button className="btn btn-success mr-2" onClick={() => setShowAddModal(true)}>Add New</button>
        <input type="file" onChange={handleFileChange} style={{ display: 'none' }} id="bulkUploadInput" />
        <label htmlFor="bulkUploadInput" className="btn btn-secondary">Add Bulk</label>
      </div>

      <table className="table table-bordered">
        <thead>
          <tr>
            <th>Title</th>
            <th>Author</th>
            <th>Price</th>
            <th>Status</th>
            <th>Cover Name</th>
            <th>Content Name</th>
            <th>Description</th>
            <th>Main Category</th>
            <th>Sub Category</th>
            <th>Placements</th>
            <th>Keywords</th>
            <th>ISBN</th>
            <th>Print Option</th>
            <th>Trim Size</th>
            <th>Bleed</th>
            <th>Paper Back Cover</th>
            <th>AI Content</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {ebooks.map((ebook) => (
            <tr key={ebook.id}>
              <td>{ebook.title}</td>
              <td>{ebook.author_first_name} {ebook.author_last_name}</td>
              <td>${ebook.price.toFixed(2)}</td>
              <td>{ebook.status}</td>
              <td>{ebook.cover_name}</td>
              <td>{ebook.content_name}</td>
              <td>{ebook.description}</td>
              <td>{ebook.category_main}</td>
              <td>{ebook.category_sub}</td>
              <td>{ebook.placements}</td>
              <td>{ebook.keywords}</td>
              <td>{ebook.isbn}</td>
              <td>{ebook.print_option}</td>
              <td>{ebook.trim_size}</td>
              <td>{ebook.bleed}</td>
              <td>{ebook.paper_back_cover}</td>
              <td>{ebook.ai_content}</td>
              <td>
                <button className="btn btn-danger" onClick={() => handleDelete(ebook.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Add New eBook Modal */}
      <Modal show={showAddModal} onHide={() => setShowAddModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Add New eBook</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={handleSubmit}>
            <Form.Group controlId="formTitle">
              <Form.Label>Title</Form.Label>
              <Form.Control type="text" placeholder="Title" value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })} required />
            </Form.Group>
            <Form.Group controlId="formAuthorFirstName">
              <Form.Label>Author First Name</Form.Label>
              <Form.Control type="text" placeholder="First Name" value={formData.author_first_name}
                onChange={(e) => setFormData({ ...formData, author_first_name: e.target.value })} />
            </Form.Group>
            <Form.Group controlId="formAuthorLastName">
              <Form.Label>Author Last Name</Form.Label>
              <Form.Control type="text" placeholder="Last Name" value={formData.author_last_name}
                onChange={(e) => setFormData({ ...formData, author_last_name: e.target.value })} />
            </Form.Group>
            <Form.Group controlId="formPrice">
              <Form.Label>Price</Form.Label>
              <Form.Control type="number" placeholder="Price" value={formData.price}
                onChange={(e) => setFormData({ ...formData, price: e.target.value })} required />
            </Form.Group>
            {/* Add other form fields similar to the table here */}
            <Button variant="success" type="submit">
              Add eBook
            </Button>
          </Form>
        </Modal.Body>
      </Modal>
    </div>
  );
};

export default EbooksTab;
