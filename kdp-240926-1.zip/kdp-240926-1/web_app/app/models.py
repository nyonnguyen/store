from pydantic import BaseModel, Field
from typing import Optional

# Pydantic model for Ebook
class EbookModel(BaseModel):
    id: int
    cover_name: str = Field(..., alias='CoverName')
    content_name: str = Field(..., alias='ContentName')
    title: str = Field(..., alias='Title')
    author_first_name: Optional[str] = Field(None, alias='AuthorFirstName')
    author_last_name: Optional[str] = Field(None, alias='AuthorLastName')
    description: Optional[str] = None
    category_main: Optional[str] = Field(None, alias='CategoryMain')
    category_sub: Optional[str] = Field(None, alias='CategorySub')
    placements: Optional[str] = Field(None, alias='CategoryPlacements')
    keywords: Optional[str] = None
    isbn: Optional[str] = None
    print_option: Optional[str] = None
    trim_size: Optional[str] = None
    bleed: Optional[bool] = None
    paper_back_cover: Optional[str] = None
    ai_content: Optional[bool] = None
    price: Optional[float] = None
    status: Optional[str] = None
    uploaded_by: Optional[str] = None

    class Config:
        allow_population_by_field_name = True

# Pydantic model for User
class UserModel(BaseModel):
    email: str
    password: str
    key: str
