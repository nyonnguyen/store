import socket
import threading

using_ports = []
lock = threading.Lock()

def is_port_in_use(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(('localhost', port)) == 0

def generate_port(start_p=5000, amount=500):
    for port in range(start_p, start_p + amount):
        with lock:
            if port not in using_ports and not is_port_in_use(port):
                using_ports.append(port)
                return port
    return None