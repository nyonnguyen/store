import subprocess
import os
import sys
import time

def start_backend():
    print("Starting backend...")
    # Start the backend using Uvicorn
    return subprocess.Popen(
        [sys.executable, '-m', 'uvicorn', 'web_app.app.main_app:app', '--host', '127.0.0.1', '--port', '8000'],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE
    )

def start_frontend():
    print("Starting frontend...")
    os.chdir("web_app/frontend")
    return subprocess.Popen('npm start', stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)


def read_process_output(process):
    # Read and print the output of the process
    while True:
        output = process.stdout.readline()
        if output == b'' and process.poll() is not None:
            break
        if output:
            print(output.decode().strip())


if __name__ == '__main__':
    backend_process = start_backend()
    time.sleep(2)  # Wait a moment for the backend to start
    frontend_process = start_frontend()

    try:
        # Create threads to read output from both processes
        from threading import Thread

        backend_thread = Thread(target=read_process_output, args=(backend_process,))
        frontend_thread = Thread(target=read_process_output, args=(frontend_process,))

        backend_thread.start()
        frontend_thread.start()

        # Keep the script running to keep both processes alive
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("Terminating processes...")
        backend_process.terminate()
        frontend_process.terminate()