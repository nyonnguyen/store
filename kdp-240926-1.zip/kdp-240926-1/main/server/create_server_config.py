import toml


class AppiumNode(object):
    def __init__(self, server, port, url, capabilities):
        self.server = server
        self.port = port
        self.url = url
        self.capabilities = capabilities

    def write_to_file(self):
        # Read and parse the template file
        with open('main/server/appium_template.toml', 'r') as template_file:
            template_data = toml.load(template_file)

        # Modify the template data as needed
        # Example modifications:
        template_data['server']['port'] = self.port
        template_data['node']['detect-drivers'] = False
        template_data['relay']['url'] = f"{self.url}"
        template_data['relay']['status-endpoint'] = "/status"
        template_data['relay']['configs'] = [
            "1", self.capabilities
        ]

        # Write the modified data to a new file
        with open('main/server/appium_new.toml', 'w') as new_file:
            toml.dump(template_data, new_file)