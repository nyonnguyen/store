import os
import json
import threading

class CookieManager:
    _instance = None
    _lock = threading.Lock()  # Lock for thread-safe file operations

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super(CookieManager, cls).__new__(cls)
        return cls._instance

    def __init__(self, file_path='cookies.json'):
        if not hasattr(self, '_initialized'):
            self.file_path = file_path
            self._initialized = True  # Ensures __init__ is run only once

    def load_cookies(self):
        if os.path.exists(self.file_path):
            with open(self.file_path, 'r') as file:
                return json.load(file)
        return {}

    def save_cookies(self, key, cookies):
        with self._lock:  # Ensure that only one thread writes to the file at a time
            current_cookies = self.load_cookies()  # Load existing cookies
            current_cookies[key] = cookies         # Add/Update the new cookie for the key
            with open(self.file_path, 'w') as file:
                json.dump(current_cookies, file, indent=4)  # Save updated cookies dictionary
            print(f"Cookie saved for {key}")

    def get_cookies(self, key):
        with self._lock:  # Ensure that only one thread reads from the file at a time
            cookies = self.load_cookies()     # Load before getting to avoid missing saved cookies
            return cookies.get(key, None)
