from appium import webdriver
from appium.options.android import UiAutomator2Options


class DriverManager(object):

    def __init__(self, url, capabilities):
        self.url = url
        # Filter out None values from capabilities
        self.capabilities = {k: v for k, v in capabilities.items() if v is not None}
        print(f"Init Driver Manager: {capabilities['deviceName']}")

    def start_driver(self):
        print("Creating webdriver...")
        driver = webdriver.Remote(self.url, options=UiAutomator2Options().load_capabilities(self.capabilities))
        print("Driver created!!")
        return driver
