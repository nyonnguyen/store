from selenium.webdriver.common.by import By
from main.helpers.element_helper import ElementLocator


class KdpLocators(ElementLocator):

    def __init__(self, driver):
        super().__init__(driver)


    CREATE_XPATH = '//*[@id="create-new-experience-button"]/span/a'
    CREATE_URL = 'https://kdp.amazon.com/en_US/create'
    CREATE_PAPER_URL = 'https://kdp.amazon.com/en_US/title-setup/paperback/new/details'

    create_paper = (By.XPATH, '//button/span[text()="Create paperback"]')

    paper_back_detail_tab = (By.XPATH, '//*[@id="book-setup-navigation-bar-details-link"]')
    paper_back_content_tab = (By.XPATH, '//*[@id="book-setup-navigation-bar-content-link"]')
    paper_back_pricing_tab = (By.XPATH, '//*[@id="book-setup-navigation-bar-pricing-link"]')

    # ============= Details Tab =============
    # Language
    LANGUAGE_DROPDOWN_XPATH = '//*[@id="print-book-language-field"]//input'

    # Book Title
    book_title_input = (By.XPATH, '//input[@id="data-print-book-title"]')
    SUBTITLE_INPUT_XPATH = '//*[@id="data-print-book-subtitle"]'  # Optional

    # Series (SKIP)

    # Edition Number (SKIP)

    # Author
    author_prefix_input = (By.XPATH, '//*[@id="data-print-book-primary-author-prefix"]')  # Optional
    author_first_name_input = (By.XPATH, '//*[@id="data-print-book-primary-author-first-name"]')
    author_middle_name_input = (By, '//*[@id="data-print-book-primary-author-middle-name"]')  # Optional
    author_last_name_input = (By.XPATH, '//*[@id="data-print-book-primary-author-last-name"]')
    author_suffix_input = (By.XPATH, '//*[@id="data-print-book-primary-author-suffix"]')  # Optional

    # Contributors (SKIP)

    # Description
    description_input = (By.CSS_SELECTOR, '#section-description input')  # Limited to 4000 characters

    # Publishing Rights
    publish_i_owns = (By.CSS_SELECTOR, '#non-public-domain')
    publish_public_domain = (By.CSS_SELECTOR, '#public-domain')

    # Primary Audience
    audience_sexual_content_no = (By.CSS_SELECTOR, '#data-print-book-is-adult-content input[value="false"]')
    audience_sexual_content_yes = (By.CSS_SELECTOR, '#data-print-book-is-adult-content input[value="true"]')
    # SKIPP AUDIENCE_AGE_XPATH

    # Primary marketplace (SKIP)
    # Default Amazon.com

    # Categories
    choose_category_button = (By.CSS_SELECTOR, '#categories-modal-button')
    # Category Dialog - Category

    ctg_diag_category_button_css = ".a-popover-wrapper span.a-dropdown-prompt"

    DROP_BUTTON_XPATH = '//div[span[text()="%s"]]/following-sibling::*//span[@class="a-button-text a-declarative"]'
    ctg_diag_category_button = (By.XPATH, DROP_BUTTON_XPATH % 'Category')
    active_popup_list = (By.XPATH, '//*[contains(@class, "a-dropdown-common") and @aria-hidden="false"]')
    # Category Dialog - Subcategory
    ctg_diag_subcategory_button = (By.XPATH, DROP_BUTTON_XPATH % 'Subcategory')
    CTG_DIAG_PLACEMENT_XPATH = '//*[contains(@class, "a-span-last") and .//text()="Placement"]//label[span/text()="%s"]'
    ctg_diag_save_button = (By.XPATH, '//button[text()="Save categories"]')

    # Keywords
    keywords_input1_input = (By.XPATH, '//*[@id="data-print-book-keywords-0"]')
    keywords_input2_input = (By.XPATH, '//*[@id="data-print-book-keywords-1"]')
    keywords_input3_input = (By.XPATH, '//*[@id="data-print-book-keywords-2"]')
    keywords_input4_input = (By.XPATH, '//*[@id="data-print-book-keywords-3"]')
    keywords_input5_input = (By.XPATH, '//*[@id="data-print-book-keywords-4"]')
    keywords_input6_input = (By.XPATH, '//*[@id="data-print-book-keywords-5"]')
    keywords_input7_input = (By.XPATH, '//*[@id="data-print-book-keywords-6"]')

    # Publication Date
    public_and_release_radio = (By.XPATH, '(//*[@id="data-print-book-previously-published-accordion"]//a[./h5])[1]')
    previous_public_radio = (By.XPATH, '(//*[@id="data-print-book-previously-published-accordion"]//a[./h5])[2]')

    # Release Date
    release_now_radio = (By.XPATH, '//*[@id="data-release-event-type-accordion"]/div[@*="RELEASE_NOW"]//a')
    release_schedule_radio = (By.XPATH, '//*[@id="data-release-event-type-accordion"]/div[@*="RELEASE_DATE"]//a')

    # ============= Content Tab =============
    # ISBN
    isbn_free_radio = (By.XPATH, '//*[@data-a-accordion-row-name="free"]//a')
    isbn_own_radio = (By.XPATH, '//*[@data-a-accordion-row-name="owner"]//a')
    isbn_assign_button = (By.XPATH, '//span[text()="Assign ISBN"]')
    isbn_assign_confirm_button = (By.XPATH, '//*[@id="free-isbn-confirm-button"]')
    isbn_success_message = (By.CSS_SELECTOR, '#print-isbn-success-alert')

    # Print Options
    PAPER_TYPE_XPATH = '//button[@name="%s"]'
    paper_type_bw_cream_button = (By.XPATH, '//button[@name="BW_CREAM"]')
    paper_type_bw_white_button = (By.XPATH, '//button[@name="BW_WHITE"]')
    paper_type_s_white_button = (By.XPATH, '//button[@name="COLOR_WHITE"]')
    paper_type_p_white_button = (By.XPATH, '//button[@name="COLOR_COLOR"]')

    # Trim Size
    trim_size_default_buton = (By.XPATH, '//*[@id="trim-size-selected-option"]//button')
    trim_size_custom_buton = (By.XPATH, '//button[@id="trim-size-btn-announce"]')
    TRIM_SIZE_SELECT_XPATH = '//*[@id="trim-size-popover"]//*[contains(text(), "%s")]'  # ex: 7 x 10

    # Bleed Settings
    no_bleed_setting_button = (By.XPATH, '//*[@id="data-print-book-interior-has-bleed-list"]//button[@name="false"]')
    bleed_setting_button = (By.XPATH, '//*[@id="data-print-book-interior-has-bleed-list"]//button[@name="true"]')

    # Paper Back
    paper_back_matte_button = (By.XPATH, '//*[@id="data-print-book-cover-finish-list"]//button[@name="MATTE"]')
    paper_back_glossy_button = (By.XPATH, '//*[@id="data-print-book-cover-finish-list"]//button[@name="GLOSSY"]')

    # Popover
    uploading_popover = (By.CSS_SELECTOR, '#uploading-popover')
    uploading_interrupt_popover = (By.CSS_SELECTOR, '#uploading-interrupt-popover')
    working_popover = (By.CSS_SELECTOR, '#working-popover')
    saving_popover = (By.CSS_SELECTOR, '#saving-popover')
    unsave_popover = (By.CSS_SELECTOR, '#unsaved-changes-popover')
    success_popover = (By.CSS_SELECTOR, '#success-popover')
    progress_popover = (By.CSS_SELECTOR, '#progress-popover')
    error_popover = (By.CSS_SELECTOR, '#error-popover')
    expire_popover = (By.CSS_SELECTOR, '#expired-popover')
    flash_popover = (By.CSS_SELECTOR, '#flash-popover')
    slot_edit_popover = (By.CSS_SELECTOR, '#slot-edit-popover')

    # Manuscript
    upload_manuscript_button = (
    By.CSS_SELECTOR, '#data-print-book-publisher-interior-file-upload-browse-button-announce')
    uploaded_success_span = (
    By.XPATH, '//*[@id="data-print-book-publisher-interior-file-upload-success"]//span[@class="success-header"]')

    # Book Cover
    upload_cover_radio = (By.XPATH, '//div[@data-a-accordion-row-name="UPLOAD"]//a')
    upload_cover_button = (By.CSS_SELECTOR, '#data-print-book-publisher-cover-file-upload-browse-button-announce')
    upload_cover_success_span = (By.CSS_SELECTOR, '#data-print-book-publisher-cover-file-upload-success')

    # AI-Generated Content (SKIP)
    gen_ai_xpath = '//div[@aria-labelledby="generative-ai-questionnaire-question"]//*[@data-a-accordion-row-name="%s"]//a'
    gen_ai_content_no_radio = (By.XPATH, gen_ai_xpath % 'no')
    gen_ai_content_yes_radio = (By.XPATH, gen_ai_xpath % 'yes')

    # Book Preview
    launch_preview_button = (By.CSS_SELECTOR, '#print-preview-announce')
    preview_continue_button = (By.XPATH, '(//*[@id="print-preview-confirm-button"]//input)[2]')
    approval_enabled_button = (By.CSS_SELECTOR, '#printpreview_approve_button_enabled a')

    # Territories
    all_territories = (By.XPATH, '//div[@data-a-accordion-row-name="on"]//a')
    inv_territories = (By.XPATH, '//div[@data-a-accordion-row-name="off"]//a')

    # Primary marketplace (SKIP)

    # Pricing, royalties, and distribution
    us_price_input = (By.CSS_SELECTOR, '#data-pricing-print-us-price-input input')  # for Amazon.com

    save_as_draft_button = (By.CSS_SELECTOR, '#save-announce')
    save_continue_button = (By.CSS_SELECTOR, '#save-and-continue-announce')
    save_publish_button = (By.CSS_SELECTOR, '#save-and-publish-announce')

    save_success_message = (By.CSS_SELECTOR, '#potter-success-alert-top')