import sqlite3

from fastapi import FastAPI, HTTPException
from web_app.app.models import EbookModel, UserModel
from main.helpers.db_helper import DBHelper
from main.model.status import Status

app = FastAPI()

db_helper = DBHelper()

# Routes for ebooks
@app.get("/ebooks/")
def get_ebooks():
    conn = db_helper.create_connection()
    ebooks = db_helper.get_all_ebooks()
    conn.close()
    return [row.to_dict() for row in ebooks]

@app.post("/ebooks/")
def add_ebook(ebook: EbookModel):
    conn = db_helper.create_connection()
    db_helper.insert_ebook(ebook)
    conn.close()
    return {"message": "Ebook added"}

@app.delete("/ebooks/{ebook_id}")
def delete_ebook(ebook_id: int):
    # TODO: implement function to delete
    return {"message": "Ebook deleted"}

# Routes for users
@app.get("/users/")
def get_users():
    conn = db_helper.create_connection()
    users = db_helper.get_users()
    conn.close()
    return [row.to_dict() for row in users]

@app.post("/users/")
def add_user(user: UserModel):
    try:
        conn = db_helper.create_connection()
        db_helper.insert_user(user)
        conn.close()
    except sqlite3.IntegrityError as e:
        raise HTTPException(status_code=400, detail="User with this email already exists")
    return {"message": "User added"}

@app.delete("/users/{email}")
def delete_user(email: str):
    # TODO: implement function to delete
    return {"message": "User deleted"}

