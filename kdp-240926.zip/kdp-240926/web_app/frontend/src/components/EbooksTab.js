import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './EbooksTab.css';

const EbooksTab = () => {
  const [ebooks, setEbooks] = useState([]);
  const [formData, setFormData] = useState({
    status: '',
    cover_name: '',
    content_name: '',
    title: '',
    author_first_name: '',
    author_last_name: '',
    description: '',
    category_main: '',
    category_sub: '',
    placements: '',
    keywords: '',
    isbn: '',
    print_option: '',
    trim_size: '',
    bleed: '',
    paper_back_cover: '',
    ai_content: '',
    uploaded_by: '',
    price: 0
  });

  const fetchEbooks = () => {
    axios.get('/ebooks/')
      .then(res => setEbooks(res.data))
      .catch(err => console.error(err));
  };

  useEffect(() => {
    fetchEbooks();
    const interval = setInterval(fetchEbooks, 30000); // Auto refresh every 5 seconds
    return () => clearInterval(interval);
  }, []);

  const handleDelete = (id) => {
    axios.delete(`/ebooks/${id}`)
      .then(fetchEbooks)
      .catch(err => console.error(err));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('/ebooks/', formData)
      .then(fetchEbooks)
      .catch(err => console.error(err));
  };

  return (
    <div className="container mt-4">
      <h3>eBooks List</h3>
      <button className="btn btn-primary mb-3" onClick={fetchEbooks}>Refresh</button>
      <table className="table table-bordered">
        <thead>
          <tr>
            <th>Title</th>
            <th>Author</th>
            <th>Price</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {ebooks.map((ebook) => (
            <tr key={ebook.id}>
              <td>{ebook.title}</td>
              <td>{ebook.author_first_name} {ebook.author_last_name}</td>
              <td>${ebook.price.toFixed(2)}</td>
              <td>
                <button className="btn btn-danger" onClick={() => handleDelete(ebook.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <h3>Add New eBook</h3>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <input type="text" className="form-control" placeholder="Cover Name" value={formData.cover_name} onChange={(e) => setFormData({ ...formData, cover_name: e.target.value })} required />
          <input type="text" className="form-control" placeholder="Content Name" value={formData.content_name} onChange={(e) => setFormData({ ...formData, content_name: e.target.value })} required />
          <input type="text" className="form-control" placeholder="Title" value={formData.title} onChange={(e) => setFormData({ ...formData, title: e.target.value })} required />
          <input type="text" className="form-control" placeholder="Author First Name" value={formData.author_first_name} onChange={(e) => setFormData({ ...formData, author_first_name: e.target.value })} />
          <input type="text" className="form-control" placeholder="Author Last Name" value={formData.author_last_name} onChange={(e) => setFormData({ ...formData, author_last_name: e.target.value })} />
          <input type="number" className="form-control" placeholder="Price" value={formData.price} onChange={(e) => setFormData({ ...formData, price: e.target.value })} />
        </div>
        <button type="submit" className="btn btn-success mt-2">Add eBook</button>
      </form>
    </div>
  );
};

export default EbooksTab;
