import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './UsersTab.css';

const UsersTab = () => {
  const [users, setUsers] = useState([]);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    key: ''
  });

  const fetchUsers = () => {
    axios.get('/users/')
      .then(res => setUsers(res.data))
      .catch(err => console.error(err));
  };

  useEffect(() => {
    fetchUsers();
    const interval = setInterval(fetchUsers, 30000); // Auto refresh every 5 seconds
    return () => clearInterval(interval);
  }, []);

  const handleDelete = (email) => {
    axios.delete(`/users/${email}`)
      .then(fetchUsers)
      .catch(err => console.error(err));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('/users/', formData)
      .then(fetchUsers)
      .catch(err => console.error(err));
  };

  return (
    <div className="container mt-4">
      <h3>Users List</h3>
      <button className="btn btn-primary mb-3" onClick={fetchUsers}>Refresh</button>
      <table className="table table-bordered">
        <thead>
          <tr>
            <th>Email</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr key={user.email}>
              <td>{user.email}</td>
              <td>
                <button className="btn btn-danger" onClick={() => handleDelete(user.email)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <h3>Add New User</h3>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <input type="email" className="form-control" placeholder="Email" value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })} required />
          <input type="password" className="form-control" placeholder="Password" value={formData.password} onChange={(e) => setFormData({ ...formData, password: e.target.value })} required />
          <input type="text" className="form-control" placeholder="Key" value={formData.key} onChange={(e) => setFormData({ ...formData, key: e.target.value })} required />
        </div>
        <button type="submit" className="btn btn-success mt-2">Add User</button>
      </form>
    </div>
  );
};

export default UsersTab;
